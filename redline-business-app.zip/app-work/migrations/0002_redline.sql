-- Shared shop board: sites, cylinders, service tags, and visits.
-- Rows are unowned on purpose so every device sees the same fleet.

create table if not exists board_meta (
  id text primary key,
  created_at timestamptz not null default now()
);

create table if not exists sites (
  id text primary key,
  name text not null,
  address text not null default '',
  notes text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists extinguishers (
  id text primary key,
  site_id text not null references sites (id),
  serial text not null,
  barcode text not null default '',
  agent text not null,
  manufacturer text not null default '',
  model text not null default '',
  rating text not null default '',
  capacity text not null default '',
  area text not null default '',
  mount text not null default '',
  manufactured_on date,
  last_monthly date,
  last_annual date,
  last_six_year date,
  last_hydro date,
  condition text not null default 'in_service',
  notes text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists extinguishers_serial_uq on extinguishers (lower(serial));
create unique index if not exists extinguishers_barcode_uq on extinguishers (lower(barcode)) where barcode <> '';
create index if not exists extinguishers_site_idx on extinguishers (site_id);

create table if not exists service_events (
  id text primary key,
  extinguisher_id text not null references extinguishers (id) on delete cascade,
  kind text not null,
  performed_on date not null,
  crew text not null default '',
  result text not null default 'pass',
  notes text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists service_events_ext_idx on service_events (extinguisher_id, performed_on desc);

create table if not exists jobs (
  id text primary key,
  site_id text not null references sites (id),
  scheduled_on date not null,
  window_label text not null default 'day',
  crew text not null default '',
  status text not null default 'scheduled',
  notes text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists jobs_date_idx on jobs (scheduled_on);
create index if not exists jobs_site_idx on jobs (site_id);
