-- Shop membership, kitchen systems, job paper, and each technician's clock.
-- shop_id is nullable here so older preview rows can be adopted by the first
-- controller. Application writes always set it and every read filters on it.

create table if not exists shops (
  id text primary key,
  name text not null default 'Shop',
  created_at timestamptz not null default now()
);

create table if not exists profiles (
  user_id text primary key,
  shop_id text not null references shops (id),
  role text not null,
  name text not null,
  created_at timestamptz not null default now()
);

create index if not exists profiles_shop_idx on profiles (shop_id);

alter table sites add column if not exists shop_id text;
alter table sites add column if not exists kind text not null default 'mixed';
alter table sites add column if not exists contact text not null default '';
alter table sites add column if not exists annual_month smallint;

alter table extinguishers add column if not exists shop_id text;
alter table extinguishers add column if not exists last_result text not null default '';

alter table jobs add column if not exists shop_id text;
alter table jobs add column if not exists work_kind text not null default 'both';
alter table jobs add column if not exists assigned_user_id text;

alter table service_events add column if not exists shop_id text;
alter table service_events alter column extinguisher_id drop not null;
alter table service_events add column if not exists kitchen_id text;

create index if not exists sites_shop_idx on sites (shop_id);
create index if not exists extinguishers_shop_idx on extinguishers (shop_id);
create index if not exists jobs_shop_idx on jobs (shop_id, scheduled_on);
create index if not exists jobs_assignee_idx on jobs (assigned_user_id);
create index if not exists service_events_kitchen_idx on service_events (kitchen_id);

create table if not exists kitchen_systems (
  id text primary key,
  shop_id text,
  site_id text not null references sites (id),
  name text not null,
  manufacturer text not null default '',
  model text not null default '',
  agent text not null default 'wet',
  fuel text not null default '',
  cylinders text not null default '1',
  nozzles text not null default '',
  links text not null default '',
  location text not null default '',
  cadence text not null default 'semiannual',
  barcode text not null default '',
  cylinder_serial text not null default '',
  last_semi date,
  last_links date,
  last_hydro date,
  last_cleaning date,
  condition text not null default 'in_service',
  notes text not null default '',
  last_result text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists kitchen_systems_site_idx on kitchen_systems (site_id);
create index if not exists kitchen_systems_shop_idx on kitchen_systems (shop_id);
create unique index if not exists kitchen_systems_barcode_uq
  on kitchen_systems (lower(barcode)) where barcode <> '';

create table if not exists job_lines (
  id text primary key,
  shop_id text,
  job_id text not null references jobs (id) on delete cascade,
  kind text not null,
  description text not null,
  qty numeric not null default 1,
  unit_label text not null default 'ea',
  rate numeric not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists job_lines_job_idx on job_lines (job_id);

create table if not exists job_photos (
  id text primary key,
  shop_id text,
  job_id text not null references jobs (id) on delete cascade,
  asset_id text not null default '',
  asset_kind text not null default 'extinguisher',
  purpose text not null default 'hydro',
  caption text not null default '',
  image text not null,
  created_at timestamptz not null default now()
);

create index if not exists job_photos_job_idx on job_photos (job_id);

create table if not exists punches (
  id text primary key,
  shop_id text,
  user_id text not null,
  crew text not null,
  kind text not null,
  job_id text,
  started_at text not null,
  ended_at text,
  created_at timestamptz not null default now()
);

create index if not exists punches_user_idx on punches (user_id, started_at);
