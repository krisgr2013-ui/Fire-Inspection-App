-- Durable invoice records with immutable line-item snapshots.
create table if not exists invoices (
  id text primary key,
  shop_id text not null references shops(id),
  job_id text not null references jobs(id),
  invoice_number text not null,
  bill_to_name text not null,
  bill_to_address text not null default '',
  bill_to_contact text not null default '',
  status text not null default 'draft' check (status in ('draft','sent','paid','void')),
  issued_on date not null,
  due_on date,
  tax_rate numeric not null default 0,
  notes text not null default '',
  paid_on date,
  created_at timestamptz not null default now(),
  unique (shop_id, invoice_number)
);
create index if not exists invoices_shop_date_idx on invoices(shop_id, issued_on desc);
create table if not exists invoice_lines (
  id text primary key,
  invoice_id text not null references invoices(id) on delete cascade,
  description text not null,
  qty numeric not null,
  unit_label text not null,
  rate numeric not null
);
create index if not exists invoice_lines_invoice_idx on invoice_lines(invoice_id);
