# Redline — business workflow additions

This build adds the business-management layer on top of the existing extinguisher fleet and scheduling app.

## Included
- Real sign-in and sign-out, with Google/X federation and email/password login.
- First signed-in account initializes an empty shop as its controller account; existing unowned preview rows are not adopted into the new tenant.
- Controller-managed technician accounts with individual email/password credentials.
- Technician job assignment, scoped job visibility, visit status updates, and job clock-in / clock-out.
- Customer directory with site address, account type, contact, annual service month, and notes.
- Work/parts line items on visits, with quantity, unit, and rate.
- Draft invoices with immutable line-item and bill-to snapshots, due date, tax rate, status tracking, and print layout.
- Compliance register and service-history report with CSV export and print support.
- Tenant-scoped server functions protected by the verified session middleware.

## First use
1. Open Redline and choose **Use email or create the shop owner account** (or a supported federated provider).
2. The first account creates the shop controller profile.
3. Add customers, then cylinders and service visits.
4. Create technician accounts from **Team** and assign visits from **Schedule**.
5. Add parts/labor to completed visits and create invoices from **Invoices**.

## Deployment notes
- The app now requires real authentication and the existing Better Auth schema migration.
- The `0004_invoices.sql` migration creates invoice headers and immutable invoice line snapshots.
- Production deployment still needs the platform-provisioned auth credentials and database connection. Validate those secrets and the deployment environment before using this with live customer records.
- The compliance report is an operational aid, not a substitute for the applicable NFPA edition, manufacturer instructions, or the authority having jurisdiction.
