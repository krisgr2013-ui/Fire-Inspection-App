import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { AGENT_LIST } from "@/lib/agents";
import type { Site, UnitDraft } from "@/lib/types";

const NEW_SITE = "__new__";

export function UnitForm({
  sites,
  initial,
  submitLabel,
  pending,
  error,
  onSubmit,
  onRemove,
}: {
  sites: Site[];
  initial: UnitDraft;
  submitLabel: string;
  pending: boolean;
  error: string | null;
  onSubmit: (draft: UnitDraft) => void;
  onRemove?: () => void;
}) {
  const [draft, setDraft] = useState(initial);
  const [removeArmed, setRemoveArmed] = useState(false);
  const creatingSite = draft.siteId === NEW_SITE;

  function set<K extends keyof UnitDraft>(key: K, value: UnitDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  return (
    <form
      className="flex flex-col gap-4"
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit({
          ...draft,
          siteId: creatingSite ? "" : draft.siteId,
          newSiteName: creatingSite ? draft.newSiteName : "",
          newSiteAddress: creatingSite ? draft.newSiteAddress : "",
        });
      }}
    >
      <Field label="Site">
        <Select
          value={draft.siteId}
          onChange={(event) => set("siteId", event.target.value)}
        >
          {sites.map((site) => (
            <option key={site.id} value={site.id}>
              {site.name}
            </option>
          ))}
          <option value={NEW_SITE}>New site</option>
        </Select>
      </Field>
      {creatingSite ? (
        <>
          <Field label="Site name">
            <Input
              value={draft.newSiteName}
              onChange={(event) => set("newSiteName", event.target.value)}
              required
              maxLength={80}
            />
          </Field>
          <Field label="Address">
            <Input
              value={draft.newSiteAddress}
              onChange={(event) => set("newSiteAddress", event.target.value)}
              maxLength={160}
            />
          </Field>
        </>
      ) : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Barcode" hint="The sticker you scan.">
          <Input
            value={draft.barcode}
            onChange={(event) => set("barcode", event.target.value)}
            autoCapitalize="characters"
            maxLength={64}
          />
        </Field>
        <Field label="Serial" hint="Stamped on the cylinder. Often the same as the barcode.">
          <Input
            value={draft.serial}
            onChange={(event) => set("serial", event.target.value)}
            required
            autoCapitalize="characters"
            maxLength={64}
          />
        </Field>
      </div>
      <Field label="Type">
        <Select value={draft.agent} onChange={(event) => set("agent", event.target.value as UnitDraft["agent"])}>
          {AGENT_LIST.map((agent) => (
            <option key={agent.key} value={agent.key}>
              {agent.label} · {agent.hydroYears}-year hydro
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Manufacturer">
          <Input value={draft.manufacturer} onChange={(event) => set("manufacturer", event.target.value)} maxLength={60} />
        </Field>
        <Field label="Model">
          <Input value={draft.model} onChange={(event) => set("model", event.target.value)} maxLength={60} />
        </Field>
        <Field label="Rating" hint="Example: 3-A:40-B:C">
          <Input value={draft.rating} onChange={(event) => set("rating", event.target.value)} maxLength={40} />
        </Field>
        <Field label="Size" hint="Example: 5 lb or 2.5 gal">
          <Input value={draft.capacity} onChange={(event) => set("capacity", event.target.value)} maxLength={40} />
        </Field>
        <Field label="Area">
          <Input value={draft.area} onChange={(event) => set("area", event.target.value)} maxLength={80} />
        </Field>
        <Field label="Mount">
          <Input value={draft.mount} onChange={(event) => set("mount", event.target.value)} maxLength={80} />
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Manufactured">
          <Input type="date" value={draft.manufacturedOn} onChange={(event) => set("manufacturedOn", event.target.value)} />
        </Field>
        <Field label="Last monthly">
          <Input type="date" value={draft.lastMonthly} onChange={(event) => set("lastMonthly", event.target.value)} />
        </Field>
        <Field label="Last annual">
          <Input type="date" value={draft.lastAnnual} onChange={(event) => set("lastAnnual", event.target.value)} />
        </Field>
        <Field label="Last 6-year">
          <Input type="date" value={draft.lastSixYear} onChange={(event) => set("lastSixYear", event.target.value)} />
        </Field>
        <Field label="Last hydrostatic">
          <Input type="date" value={draft.lastHydro} onChange={(event) => set("lastHydro", event.target.value)} />
        </Field>
        <Field label="Condition">
          <Select
            value={draft.condition}
            onChange={(event) => set("condition", event.target.value as UnitDraft["condition"])}
          >
            <option value="in_service">In service</option>
            <option value="out">Out of service</option>
            <option value="condemned">Condemned</option>
          </Select>
        </Field>
      </div>
      <Field label="Notes">
        <Textarea value={draft.notes} onChange={(event) => set("notes", event.target.value)} maxLength={500} />
      </Field>
      {error ? <p className="text-sm text-signal">{error}</p> : null}
      <Button type="submit" size="block" disabled={pending}>
        {pending ? "Saving…" : submitLabel}
      </Button>
      {onRemove ? (
        removeArmed ? (
          <Button type="button" variant="quiet" size="block" disabled={pending} onClick={onRemove}>
            Remove this cylinder
          </Button>
        ) : (
          <Button type="button" variant="ghost" size="block" onClick={() => setRemoveArmed(true)}>
            Remove from board
          </Button>
        )
      ) : null}
    </form>
  );
}

export function emptyDraft(code = "", siteId = ""): UnitDraft {
  return {
    siteId,
    newSiteName: "",
    newSiteAddress: "",
    serial: code,
    barcode: code,
    agent: "abc",
    manufacturer: "",
    model: "",
    rating: "",
    capacity: "",
    area: "",
    mount: "",
    manufacturedOn: "",
    lastMonthly: "",
    lastAnnual: "",
    lastSixYear: "",
    lastHydro: "",
    condition: "in_service",
    notes: "",
  };
}
