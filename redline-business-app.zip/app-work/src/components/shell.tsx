import { Link, useRouterState } from "@tanstack/react-router";
import { CalendarDays, ClipboardList, Rows3, ScanLine, Building2, Users, ChartNoAxesCombined, ReceiptText } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { SignInGate, SignInButtons, UserButton } from "@/lib/auth/gates";
import { useBoard } from "@/lib/use-board";

const NAV = [
  { to: "/", label: "Board", icon: ClipboardList, match: (path: string) => path === "/" },
  { to: "/fleet", label: "Fleet", icon: Rows3, match: (path: string) => path.startsWith("/fleet") || path.startsWith("/unit") },
  { to: "/scan", label: "Scan", icon: ScanLine, match: (path: string) => path.startsWith("/scan") },
  { to: "/schedule", label: "Schedule", icon: CalendarDays, match: (path: string) => path.startsWith("/schedule") || path.startsWith("/job") },
  { to: "/clients", label: "Customers", icon: Building2, match: (path: string) => path.startsWith("/clients") },
  { to: "/reports", label: "Reports", icon: ChartNoAxesCombined, match: (path: string) => path.startsWith("/reports") },
  { to: "/invoices", label: "Invoices", icon: ReceiptText, match: (path: string) => path.startsWith("/invoices") },
  { to: "/team", label: "Team", icon: Users, match: (path: string) => path.startsWith("/team") },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  return (
    <SignInGate fallback={<div className="min-h-dvh bg-bg px-5 py-16 text-fg"><div className="mx-auto flex max-w-sm flex-col gap-4"><Wordmark /><h1 className="font-display text-4xl uppercase">Welcome to Redline</h1><p className="text-sm text-muted">Sign in to access your shop, customers, inspections, and team.</p><SignInButtons /><Link to="/login" className="min-h-11 text-center text-sm font-semibold underline text-muted">Use email or create the shop owner account</Link></div></div>}>
      <SignedInShell pathname={pathname}>{children}</SignedInShell>
    </SignInGate>
  );
}

function SignedInShell({ pathname, children }: { pathname: string; children: ReactNode }) {
  const board = useBoard();
  const navItems = board.view?.role === "tech" ? NAV.filter((item) => !["/team", "/invoices", "/reports"].includes(item.to)) : NAV;
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh w-full max-w-5xl md:grid md:grid-cols-[13.5rem_minmax(0,1fr)]">
        <aside className="hidden border-r border-line md:flex md:flex-col md:gap-6 md:px-4 md:py-6">
          <Wordmark />
          <nav className="flex flex-col gap-1">
            {navItems.map((item) => {
              const on = item.match(pathname);
              const Icon = item.icon;
              return <Link key={item.to} to={item.to} className={cn("flex min-h-11 items-center gap-3 rounded-md px-3 text-base font-medium", on ? "bg-surface text-fg" : "text-muted hover:bg-surface hover:text-fg")}><Icon className="size-5" aria-hidden />{item.label}</Link>;
            })}
          </nav>
          <p className="mt-auto text-sm text-muted text-pretty">One shop board. A scan or a tag on any phone shows up on the others.</p>
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-bg px-4 py-3 md:px-6">
            <div className="md:hidden"><Wordmark /></div>
            <p className="hidden text-sm text-muted md:block">NFPA 10 shop board</p>
            <div className="flex items-center gap-3"><p className="flex items-center gap-2 text-sm text-muted"><span className={cn("size-2 rounded-full bg-fg", board.isFetching ? "opacity-40" : "opacity-100")} />{board.isFetching ? "Syncing" : "Live"}</p><UserButton /></div>
          </header>
          <main className="flex-1 px-4 py-5 pb-28 md:px-6 md:pb-10">{children}</main>
        </div>
      </div>
      <nav className="dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg md:hidden"><div className="mx-auto grid max-w-5xl grid-cols-4">
        {navItems.map((item) => { const on = item.match(pathname); const Icon = item.icon; return <Link key={item.to} to={item.to} className={cn("flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold", on ? "text-fg" : "text-faint")}><Icon className="size-5" aria-hidden />{item.label}</Link>; })}
      </div></nav>
    </div>
  );
}

function Wordmark() {
  return (
    <Link to="/" className="flex items-center gap-2">
      <span className="h-5 w-1 rounded-full bg-signal" aria-hidden />
      <span className="font-display text-3xl leading-none tracking-wide text-fg uppercase">Redline</span>
    </Link>
  );
}

export function PageHeader({ title, lede }: { title: string; lede?: string }) {
  return (
    <header className="mb-5">
      <h1 className="font-display text-5xl leading-none tracking-wide text-fg uppercase">{title}</h1>
      {lede ? <p className="mt-2 max-w-xl text-base text-muted text-pretty">{lede}</p> : null}
    </header>
  );
}

export function SkeletonBlock() {
  return (
    <div className="flex flex-col gap-3" aria-hidden>
      <div className="h-20 animate-pulse rounded-2xl bg-surface motion-reduce:animate-none" />
      <div className="h-20 animate-pulse rounded-2xl bg-surface motion-reduce:animate-none" />
      <div className="h-20 animate-pulse rounded-2xl bg-surface motion-reduce:animate-none" />
    </div>
  );
}
