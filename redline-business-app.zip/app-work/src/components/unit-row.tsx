import { Link } from "@tanstack/react-router";
import { ClassPlate, StatusBadge } from "@/components/marks";
import type { DecoratedUnit } from "@/lib/use-board";

export function UnitRow({ unit }: { unit: DecoratedUnit }) {
  const place = [unit.siteName, unit.area].filter(Boolean).join(" · ");
  return (
    <Link
      to="/unit/$id"
      params={{ id: unit.id }}
      className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-3 transition-colors duration-200 ease-out hover:bg-surface-2"
    >
      <ClassPlate agent={unit.agent} />
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-2">
          <span className="truncate font-display text-2xl leading-none tracking-wide text-fg">
            {unit.serial}
          </span>
        </span>
        <span className="mt-1 block truncate text-sm text-muted">
          {unit.capacity ? `${unit.capacity} · ` : ""}
          {place || "No location"}
        </span>
        <span className="mt-0.5 block truncate text-sm text-faint">{unit.compliance.headline}</span>
      </span>
      <StatusBadge worst={unit.compliance.worst} condition={unit.condition} />
    </Link>
  );
}
