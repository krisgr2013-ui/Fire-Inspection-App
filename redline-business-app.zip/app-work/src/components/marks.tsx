import { AGENTS } from "@/lib/agents";
import { cn } from "@/lib/cn";
import type { ClockState, Worst } from "@/lib/nfpa";
import type { AgentKey, Condition } from "@/lib/types";

const BADGE: Record<Worst | ClockState, { label: string; className: string }> = {
  overdue: { label: "Overdue", className: "bg-signal text-on-signal" },
  unknown: { label: "Unverified", className: "border border-line bg-surface-2 text-fg" },
  due: { label: "Due soon", className: "bg-due text-on-due" },
  ok: { label: "Current", className: "border border-line text-ok" },
  out: { label: "Out", className: "border border-line text-muted" },
  na: { label: "Not required", className: "border border-line text-faint" },
};

export function StatusBadge({
  worst,
  condition,
}: {
  worst: Worst | ClockState;
  condition?: Condition;
}) {
  const tone =
    condition === "condemned"
      ? { label: "Condemned", className: "bg-signal text-on-signal" }
      : condition === "out"
        ? { label: "Out of service", className: "border border-line text-muted" }
        : BADGE[worst];
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-xs font-semibold",
        tone.className,
      )}
    >
      {tone.label}
    </span>
  );
}

export function ClassPlate({ agent }: { agent: AgentKey }) {
  const info = AGENTS[agent];
  return (
    <span className="inline-flex h-11 min-w-11 shrink-0 items-center justify-center rounded-md border border-line bg-bg px-1.5 font-display text-lg leading-none tracking-wide text-fg">
      {info.plate}
    </span>
  );
}
