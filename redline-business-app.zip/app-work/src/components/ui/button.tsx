import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-base font-semibold transition-colors duration-200 ease-out disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-fg",
  {
    variants: {
      variant: {
        primary: "bg-fg text-bg hover:opacity-90",
        quiet: "border border-line bg-surface text-fg hover:bg-surface-2",
        ghost: "bg-transparent text-muted hover:bg-surface hover:text-fg",
      },
      size: {
        md: "h-11 px-4",
        sm: "h-9 px-3 text-sm",
        block: "h-12 w-full px-4",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean };

export function Button({ className, variant, size, asChild = false, type = "button", ...props }: ButtonProps) {
  const classes = cn(buttonVariants({ variant, size }), className);
  if (asChild) return <Slot className={classes} {...props} />;
  return <button type={type} className={classes} {...props} />;
}
