import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHeader, Shell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { cleanError } from "@/lib/clean-error";
import { createTech, listTechs } from "@/lib/redline.functions";

export const Route = createFileRoute("/team")({ component: TeamRoute });
function TeamRoute() { return <Shell><TeamPage /></Shell>; }
function TeamPage() {
  const [people,setPeople] = useState<{userId:string;name:string;email:string}[]>([]);
  const [name,setName] = useState(""); const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [pending,setPending] = useState(false); const [error,setError] = useState<string|null>(null); const [message,setMessage] = useState("");
  async function load(){ try { setPeople(await listTechs()); } catch(e){setError(cleanError(e));} }
  useEffect(()=>{void load();},[]);
  return <div className="flex flex-col gap-4"><PageHeader title="Team" lede="Technician accounts are scoped to this shop. Give each person their own login." />
    <form className="flex flex-col gap-3 rounded-2xl border border-line bg-surface p-4" onSubmit={async(e)=>{e.preventDefault();setPending(true);setError(null);setMessage("");try{await createTech({data:{name,email,password}});setName("");setEmail("");setPassword("");setMessage("Technician account created. Share the temporary password securely.");await load();}catch(err){setError(cleanError(err));}finally{setPending(false);}}}>
      <h2 className="text-lg font-semibold">Add technician</h2><Field label="Full name"><Input value={name} onChange={e=>setName(e.target.value)} required minLength={2} maxLength={80}/></Field><Field label="Email login"><Input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></Field><Field label="Temporary password"><Input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} maxLength={72}/></Field>
      {error&&<p className="text-sm text-signal">{error}</p>}{message&&<p className="text-sm text-muted">{message}</p>}<Button type="submit" size="block" disabled={pending}>{pending?"Creating…":"Create account"}</Button>
    </form>
    <section className="flex flex-col gap-2"><h2 className="text-lg font-semibold">Technicians</h2>{people.length===0?<p className="rounded-2xl border border-line p-4 text-sm text-muted">No technician accounts added yet.</p>:people.map(p=><div key={p.userId} className="rounded-xl border border-line bg-surface p-4"><p className="font-semibold">{p.name}</p><p className="text-sm text-muted">{p.email}</p></div>)}</section>
  </div>;
}
