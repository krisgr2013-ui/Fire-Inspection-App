import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { emptyDraft, UnitForm } from "@/components/unit-form";
import { cleanError } from "@/lib/clean-error";
import { createUnit } from "@/lib/redline.functions";
import { useBoard, useRefresh } from "@/lib/use-board";

export const Route = createFileRoute("/unit/new")({
  validateSearch: (search: Record<string, unknown>) => ({
    code: typeof search.code === "string" ? search.code.slice(0, 80) : "",
  }),
  component: NewRoute,
});

function NewRoute() {
  return (
    <Shell>
      <NewUnit />
    </Shell>
  );
}

function NewUnit() {
  const { code } = Route.useSearch();
  const navigate = useNavigate();
  const refresh = useRefresh();
  const { view, isLoading } = useBoard();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-4">
      <Link to="/fleet" search={{ view: "all" }} className="text-sm font-medium text-muted">
        Back to fleet
      </Link>
      <PageHeader
        title="Add"
        lede="Barcode is the sticker. Serial is the number stamped on the cylinder."
      />
      {isLoading || !view ? (
        <SkeletonBlock />
      ) : (
        <UnitForm
          sites={view.sites}
          initial={emptyDraft(code, view.sites[0]?.id ?? "")}
          submitLabel="Save cylinder"
          pending={pending}
          error={error}
          onSubmit={async (draft) => {
            setPending(true);
            setError(null);
            try {
              const saved = await createUnit({ data: draft });
              refresh();
              await navigate({ to: "/unit/$id", params: { id: saved.id } });
            } catch (err) {
              setError(cleanError(err));
              setPending(false);
            }
          }}
        />
      )}
    </div>
  );
}
