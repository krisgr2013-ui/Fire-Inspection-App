import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ClassPlate, StatusBadge } from "@/components/marks";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { UnitForm } from "@/components/unit-form";
import { agentOf } from "@/lib/agents";
import { cleanError } from "@/lib/clean-error";
import { formatPretty } from "@/lib/dates";
import { KIND_LABEL, RESULT_LABEL } from "@/lib/labels";
import { clockPhrase, compliance, type Clock, type ClockKey } from "@/lib/nfpa";
import { getUnit, recordService, removeUnit, updateUnit } from "@/lib/redline.functions";
import type { ServiceKind, ServiceResult, Unit, UnitDraft } from "@/lib/types";
import { useBoard, useClientToday, useRefresh } from "@/lib/use-board";

export const Route = createFileRoute("/unit/$id")({ component: UnitRoute });

function UnitRoute() {
  return (
    <Shell>
      <UnitPage />
    </Shell>
  );
}

function UnitPage() {
  const { id } = Route.useParams();
  const today = useClientToday();
  const board = useBoard();
  const refresh = useRefresh();
  const navigate = useNavigate();
  const query = useQuery({
    queryKey: ["unit", id],
    queryFn: () => getUnit({ data: { id } }),
    refetchInterval: 4000,
  });
  const [editing, setEditing] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (query.isError) {
    return (
      <div>
        <Link to="/fleet" search={{ view: "all" }} className="text-sm font-medium text-muted">
          Back to fleet
        </Link>
        <p className="mt-4 text-sm text-signal">{cleanError(query.error)}</p>
      </div>
    );
  }
  if (query.isLoading || !query.data || !today) return <SkeletonBlock />;

  const { unit, site, events } = query.data;
  const agent = agentOf(unit.agent);
  const live = compliance(unit, today);

  if (editing) {
    if (!board.view) return <SkeletonBlock />;
    return (
      <div className="flex flex-col gap-4">
        <button type="button" className="text-left text-sm font-medium text-muted" onClick={() => setEditing(false)}>
          Cancel edit
        </button>
        <PageHeader title={unit.serial} lede="Update the tag, the mount, or the dates already on the cylinder." />
        <UnitForm
          sites={board.view.sites}
          initial={toDraft(unit)}
          submitLabel="Save changes"
          pending={pending}
          error={error}
          onSubmit={async (draft) => {
            setPending(true);
            setError(null);
            try {
              await updateUnit({ data: { id: unit.id, draft } });
              refresh();
              setEditing(false);
            } catch (err) {
              setError(cleanError(err));
            } finally {
              setPending(false);
            }
          }}
          onRemove={async () => {
            setPending(true);
            setError(null);
            try {
              await removeUnit({ data: { id: unit.id } });
              refresh();
              await navigate({ to: "/fleet", search: { view: "all" } });
            } catch (err) {
              setError(cleanError(err));
              setPending(false);
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <Link to="/fleet" search={{ view: "all" }} className="text-sm font-medium text-muted">
        Back to fleet
      </Link>
      <div className="flex items-start gap-3">
        <ClassPlate agent={unit.agent} />
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-display text-5xl leading-none tracking-wide uppercase">{unit.serial}</h1>
          <p className="mt-2 text-base text-muted">
            {agent.label}
            {unit.capacity ? ` · ${unit.capacity}` : ""}
            {unit.rating ? ` · ${unit.rating}` : ""}
          </p>
        </div>
      </div>
      {live ? <StatusBadge worst={live.worst} condition={unit.condition} /> : null}

      <section className="rounded-2xl border border-line bg-surface p-4">
        <p className="text-lg font-semibold">{site.name}</p>
        <p className="mt-1 text-sm text-muted">{[unit.area, unit.mount].filter(Boolean).join(" · ") || "No mount noted"}</p>
        {site.address ? (
          <a
            className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold"
            href={`https://maps.google.com/maps?q=${encodeURIComponent(site.address)}`}
            target="_blank"
            rel="noreferrer"
          >
            Directions
          </a>
        ) : null}
        {unit.barcode ? <p className="text-sm text-faint">Barcode {unit.barcode}</p> : null}
        {unit.manufacturer || unit.model ? (
          <p className="text-sm text-faint">{[unit.manufacturer, unit.model].filter(Boolean).join(" · ")}</p>
        ) : null}
        {unit.notes ? <p className="mt-2 text-sm text-muted text-pretty">{unit.notes}</p> : null}
      </section>

      <section>
        <h2 className="text-lg font-semibold">{live.headline}</h2>
        <div className="mt-2">
          {live.clocks.map((clock) => (
              <div key={clock.key} className="flex items-start justify-between gap-3 border-t border-line py-3">
                <div>
                  <p className="font-medium">{clock.label}</p>
                  <p className="text-sm text-muted">{clockPhrase(clock, today)}</p>
                  <p className="text-sm text-faint">
                    Last {clock.last ? formatPretty(clock.last) : "—"}
                    {clock.next && clock.state !== "na" ? ` · Next ${formatPretty(clock.next)}` : ""}
                  </p>
                </div>
                <StatusBadge worst={clock.state} />
              </div>
            ))}
        </div>
      </section>

      <RecordForm
        key={`${unit.id}-${today}`}
        unitId={unit.id}
        today={today}
        sixYear={agent.sixYear}
        suggested={suggestedKind(live.clocks, agent.sixYear)}
      />

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Tag history</h2>
        {events.length === 0 ? (
          <p className="text-sm text-muted">No service recorded yet.</p>
        ) : (
          <ul className="flex flex-col gap-3">
            {events.map((event) => (
              <li key={event.id} className="border-t border-line pt-3">
                <p className="font-medium">
                  {KIND_LABEL[event.kind]} · {RESULT_LABEL[event.result]}
                </p>
                <p className="text-sm text-muted">
                  {formatPretty(event.performedOn)}
                  {event.crew ? ` · ${event.crew}` : ""}
                </p>
                {event.notes ? <p className="text-sm text-faint text-pretty">{event.notes}</p> : null}
              </li>
            ))}
          </ul>
        )}
      </section>

      <Button variant="quiet" size="block" onClick={() => setEditing(true)}>
        Edit cylinder
      </Button>

      <details className="rounded-2xl border border-line bg-surface p-4">
        <summary className="cursor-pointer text-base font-medium">How these dates are figured</summary>
        <ul className="mt-3 flex flex-col gap-2 text-sm text-muted">
          {(live.clocks).map((clock) => (
            <li key={clock.key}>
              <span className="text-fg">{clock.label}.</span> {clock.cite}. {clock.note}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-faint text-pretty">
          Field aid from NFPA 10: monthly inspection, annual maintenance, a 6-year internal on 12-year
          hydrostatic types, and a 5- or 12-year hydro test by agent. Confirm against the edition you work to
          and the cylinder nameplate.
        </p>
      </details>
    </div>
  );
}

function suggestedKind(clocks: Clock[], sixYear: boolean): ServiceKind {
  const order: ClockKey[] = ["hydro", "six_year", "annual", "monthly"];
  for (const key of order) {
    const clock = clocks.find((item) => item.key === key);
    if (!clock || clock.state === "na" || clock.state === "ok") continue;
    if (key === "six_year" && !sixYear) continue;
    return key;
  }
  return "annual";
}

function toDraft(unit: Unit): UnitDraft {
  return {
    siteId: unit.siteId,
    newSiteName: "",
    newSiteAddress: "",
    serial: unit.serial,
    barcode: unit.barcode,
    agent: unit.agent,
    manufacturer: unit.manufacturer,
    model: unit.model,
    rating: unit.rating,
    capacity: unit.capacity,
    area: unit.area,
    mount: unit.mount,
    manufacturedOn: unit.manufacturedOn ?? "",
    lastMonthly: unit.lastMonthly ?? "",
    lastAnnual: unit.lastAnnual ?? "",
    lastSixYear: unit.lastSixYear ?? "",
    lastHydro: unit.lastHydro ?? "",
    condition: unit.condition,
    notes: unit.notes,
  };
}

const CREW_KEY = "redline-tag-name";

function RecordForm({
  unitId,
  today,
  sixYear,
  suggested,
}: {
  unitId: string;
  today: string;
  sixYear: boolean;
  suggested: ServiceKind;
}) {
  const refresh = useRefresh();
  const [kind, setKind] = useState<ServiceKind>(suggested);
  const [performedOn, setPerformedOn] = useState(today);
  const [crew, setCrew] = useState("");
  const [result, setResult] = useState<ServiceResult>("pass");
  const [notes, setNotes] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(CREW_KEY);
      if (stored) setCrew(stored);
    } catch {
      /* private mode */
    }
  }, []);

  const kinds: ServiceKind[] = sixYear
    ? ["monthly", "annual", "six_year", "hydro", "recharge"]
    : ["monthly", "annual", "hydro", "recharge"];

  return (
    <form
      className="flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4"
      onSubmit={async (event) => {
        event.preventDefault();
        setPending(true);
        setError(null);
        setSaved(false);
        try {
          if (crew.trim()) localStorage.setItem(CREW_KEY, crew.trim());
          await recordService({
            data: { unitId, kind, performedOn, crew, result, notes },
          });
          refresh();
          setNotes("");
          setSaved(true);
        } catch (err) {
          setError(cleanError(err));
        } finally {
          setPending(false);
        }
      }}
    >
      <h2 className="text-lg font-semibold">Record service</h2>
      <div className="flex flex-wrap gap-2">
        {kinds.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setKind(item)}
            className={
              kind === item
                ? "h-9 rounded-full bg-fg px-3 text-sm font-semibold text-bg"
                : "h-9 rounded-full border border-line px-3 text-sm font-semibold text-muted"
            }
          >
            {KIND_LABEL[item]}
          </button>
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Date performed">
          <Input type="date" max={today} value={performedOn} onChange={(event) => setPerformedOn(event.target.value)} required />
        </Field>
        <Field label="Name on tag">
          <Input value={crew} onChange={(event) => setCrew(event.target.value)} maxLength={40} placeholder="Initials or truck" />
        </Field>
      </div>
      <Field label="Result">
        <Select value={result} onChange={(event) => setResult(event.target.value as ServiceResult)}>
          <option value="pass">Pass</option>
          <option value="deficient">Deficient / repair needed</option>
          <option value="fail">Fail</option>
        </Select>
      </Field>
      <Field label="Notes">
        <Textarea value={notes} onChange={(event) => setNotes(event.target.value)} maxLength={500} />
      </Field>
      {error ? <p className="text-sm text-signal">{error}</p> : null}
      {saved ? <p className="text-sm text-ok">Saved to the shared board.</p> : null}
      <Button type="submit" size="block" disabled={pending}>
        {pending ? "Saving…" : "Save service"}
      </Button>
    </form>
  );
}
