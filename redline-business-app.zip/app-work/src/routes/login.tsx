import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { authClient } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";

export const Route = createFileRoute("/login")({ component: Login });
function Login() {
  const navigate = useNavigate();
  const [mode,setMode] = useState<"signin"|"signup">("signin");
  const [name,setName] = useState(""); const [email,setEmail] = useState(""); const [password,setPassword] = useState("");
  const [pending,setPending] = useState(false); const [error,setError] = useState("");
  async function submit(e: FormEvent) { e.preventDefault(); setPending(true); setError(""); try {
    const result = mode === "signup" ? await authClient.signUp.email({name,email,password}) : await authClient.signIn.email({email,password});
    if (result.error) throw new Error(result.error.message || "Could not authenticate.");
    await navigate({to:"/"});
  } catch(err) { setError(err instanceof Error ? err.message : "Could not authenticate."); } finally { setPending(false); } }
  return <main className="grid min-h-dvh place-items-center bg-bg px-5 py-10 text-fg"><div className="w-full max-w-sm"><div className="mb-8 flex items-center gap-2"><span className="h-6 w-1 rounded-full bg-signal"/><span className="font-display text-4xl uppercase tracking-wide">Redline</span></div><h1 className="font-display text-4xl uppercase">{mode === "signup" ? "Create shop account" : "Sign in"}</h1><p className="mb-6 mt-2 text-sm text-muted">Secure access to your inspection shop.</p>
    {authEnabled && <div className="mb-5 flex flex-col gap-2">{GROK_PROVIDERS.map(p=><Button key={p.providerId} variant="quiet" size="block" onClick={()=>signIn(p.providerId,{callbackURL:"/"})}>Continue with {p.label}</Button>)}</div>}
    <div className="mb-4 flex items-center gap-3 text-xs text-faint"><span className="h-px flex-1 bg-line"/>OR EMAIL<span className="h-px flex-1 bg-line"/></div>
    <form className="flex flex-col gap-3" onSubmit={submit}>{mode==="signup"&&<Field label="Your name"><Input value={name} onChange={e=>setName(e.target.value)} required minLength={2}/></Field>}<Field label="Email"><Input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/></Field><Field label="Password"><Input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} autoComplete={mode==="signup"?"new-password":"current-password"}/></Field>{error&&<p className="text-sm text-signal">{error}</p>}<Button type="submit" size="block" disabled={pending}>{pending?"Please wait…":mode==="signup"?"Create account":"Sign in with email"}</Button></form>
    <button className="mt-5 min-h-11 text-sm font-semibold text-muted underline" type="button" onClick={()=>{setMode(mode==="signup"?"signin":"signup");setError("");}}>{mode==="signup"?"Already have an account? Sign in":"First time here? Create the shop owner account"}</button>
  </div></main>;
}
