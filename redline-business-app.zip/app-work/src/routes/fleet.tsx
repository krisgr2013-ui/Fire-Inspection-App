import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UnitRow } from "@/components/unit-row";
import { agentOf } from "@/lib/agents";
import { cn } from "@/lib/cn";
import { cleanError } from "@/lib/clean-error";
import { useBoard, type DecoratedUnit } from "@/lib/use-board";

type FleetView = "all" | "attention" | "due" | "ok" | "out";

export const Route = createFileRoute("/fleet")({
  validateSearch: (search: Record<string, unknown>): { view: FleetView } => {
    const view = search.view;
    if (view === "attention" || view === "due" || view === "ok" || view === "out") return { view };
    return { view: "all" };
  },
  component: FleetRoute,
});

function FleetRoute() {
  return (
    <Shell>
      <FleetPage />
    </Shell>
  );
}

const FILTERS: { id: FleetView; label: string }[] = [
  { id: "all", label: "All" },
  { id: "attention", label: "Attention" },
  { id: "due", label: "Due soon" },
  { id: "ok", label: "Current" },
  { id: "out", label: "Out" },
];

function matches(unit: DecoratedUnit, view: FleetView): boolean {
  if (view === "all") return true;
  if (view === "attention") return unit.compliance.worst === "overdue" || unit.compliance.worst === "unknown";
  if (view === "due") return unit.compliance.worst === "due";
  if (view === "ok") return unit.compliance.worst === "ok";
  return unit.compliance.worst === "out";
}

function FleetPage() {
  const { view: fleetView } = Route.useSearch();
  const { view, isLoading, isError, error, refetch } = useBoard();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FleetView>(fleetView);

  const units = useMemo(() => {
    if (!view) return [];
    const needle = query.trim().toLowerCase();
    return view.units.filter((unit) => {
      if (!matches(unit, filter)) return false;
      if (!needle) return true;
      const agent = agentOf(unit.agent);
      const hay = [unit.serial, unit.barcode, unit.siteName, unit.area, unit.mount, unit.manufacturer, agent.label]
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    });
  }, [view, query, filter]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-end justify-between gap-3">
        <PageHeader title="Fleet" lede="Every cylinder, with the next NFPA date on the tag." />
      </div>
      <div className="flex items-center gap-2">
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Serial, site, or type"
          aria-label="Search the fleet"
        />
        <Button asChild variant="quiet">
          <Link to="/unit/new" search={{ code: "" }}>
            Add
          </Link>
        </Button>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={cn(
              "h-9 shrink-0 rounded-full px-3 text-sm font-semibold",
              filter === item.id ? "bg-fg text-bg" : "border border-line bg-surface text-muted",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      {isError ? (
        <div>
          <p className="text-sm text-signal">{cleanError(error)}</p>
          <button type="button" className="mt-2 h-11 text-base font-semibold" onClick={() => void refetch()}>
            Try again
          </button>
        </div>
      ) : isLoading || !view ? (
        <SkeletonBlock />
      ) : units.length === 0 ? (
        <p className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">
          No cylinders in this view. Scan a barcode or add one by hand.
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {units.map((unit) => (
            <UnitRow key={unit.id} unit={unit} />
          ))}
        </div>
      )}
    </div>
  );
}
