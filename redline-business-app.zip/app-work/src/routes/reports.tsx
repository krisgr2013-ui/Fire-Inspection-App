import { createFileRoute } from "@tanstack/react-router";
import { Download, Printer } from "lucide-react";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { formatPretty } from "@/lib/dates";
import { KIND_LABEL, RESULT_LABEL } from "@/lib/labels";
import { useBoard } from "@/lib/use-board";

export const Route = createFileRoute("/reports")({ component: ReportsRoute });
function ReportsRoute(){return <Shell><ReportsPage/></Shell>}
function ReportsPage(){
 const {view,today,isLoading}=useBoard(); if(isLoading||!view||!today)return <SkeletonBlock/>;
 const rows=view.units.map(u=>({serial:u.serial,site:u.siteName,condition:u.condition,status:u.compliance.worst,next:u.compliance.clocks.filter(c=>c.next).sort((a,b)=>(a.next||"").localeCompare(b.next||""))[0]?.next??""}));
 const assetNames = new Map([...view.units.map(u=>[u.id,u.serial] as const), ...view.kitchens.map(k=>[k.id,k.name] as const)]);
 const eventRows = view.events.map(e=>({asset:assetNames.get(e.extinguisherId??e.kitchenId??"")??"Asset",customer:view.sitesById.get(view.units.find(u=>u.id===e.extinguisherId)?.siteId??view.kitchens.find(k=>k.id===e.kitchenId)?.siteId??"")?.name??"",date:e.performedOn,kind:KIND_LABEL[e.kind],result:RESULT_LABEL[e.result],crew:e.crew,notes:e.notes}));
 const csv=["Record type,Asset,Customer,Date,Status,Technician,Notes",...rows.map(r=>["Compliance",r.serial,r.site,"",r.status,"",r.next?`Next due ${r.next}`:""].map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")),...eventRows.map(e=>[e.kind,e.asset,e.customer,e.date,e.result,e.crew,e.notes].map(v=>`"${String(v).replaceAll('"','""')}"`).join(","))].join("\n");
 function download(){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download=`redline-compliance-${today}.csv`;a.click();URL.revokeObjectURL(a.href)}
 const attention=rows.filter(r=>r.status==="overdue"||r.status==="unknown").length; const due=rows.filter(r=>r.status==="due").length;
 return <div className="flex flex-col gap-5"><PageHeader title="Reports" lede={`Fleet compliance snapshot · ${formatPretty(today)}`} />
 <div className="grid grid-cols-3 gap-2"><div className="rounded-xl border border-line bg-surface p-3"><strong className="font-display text-3xl">{rows.length}</strong><p className="text-xs text-muted">Assets</p></div><div className="rounded-xl border border-line bg-surface p-3"><strong className="font-display text-3xl">{attention}</strong><p className="text-xs text-muted">Attention</p></div><div className="rounded-xl border border-line bg-surface p-3"><strong className="font-display text-3xl">{due}</strong><p className="text-xs text-muted">Due soon</p></div></div>
 <div className="flex gap-2"><Button className="flex-1" onClick={download}><Download className="mr-2 size-4"/>Export CSV</Button><Button variant="quiet" className="flex-1" onClick={()=>window.print()}><Printer className="mr-2 size-4"/>Print report</Button></div>
 <section className="flex flex-col gap-2"><h2 className="text-lg font-semibold">Asset compliance register</h2>{rows.length===0?<p className="text-sm text-muted">No assets to report.</p>:rows.map(r=><div key={r.serial} className="flex items-center justify-between gap-3 border-t border-line py-3"><div className="min-w-0"><p className="font-semibold">{r.serial}</p><p className="truncate text-sm text-muted">{r.site}</p></div><div className="text-right"><p className="text-sm font-semibold capitalize">{r.status.replace("_"," ")}</p><p className="text-xs text-muted">{r.next?`Next ${formatPretty(r.next)}`:"No date set"}</p></div></div>)}</section>
 <section className="flex flex-col gap-2"><h2 className="text-lg font-semibold">Inspection & service history</h2>{eventRows.length===0?<p className="text-sm text-muted">No service events recorded yet.</p>:eventRows.map((e,i)=><div key={`${e.asset}-${e.date}-${i}`} className="border-t border-line py-3"><div className="flex justify-between gap-3"><p className="font-semibold">{e.asset}</p><p className="text-sm text-muted">{formatPretty(e.date)}</p></div><p className="text-sm text-muted">{e.kind} · {e.result}{e.crew?` · ${e.crew}`:""}</p>{e.notes&&<p className="text-sm text-faint">{e.notes}</p>}</div>)}</section>
 <p className="text-xs text-faint">Operational aid only. Confirm inspection intervals, acceptance criteria, and local requirements against the applicable NFPA edition and authority having jurisdiction.</p></div>
}
