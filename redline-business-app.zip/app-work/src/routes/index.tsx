import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { UnitRow } from "@/components/unit-row";
import { longDay } from "@/lib/dates";
import { WINDOW_LABEL } from "@/lib/labels";
import { cleanError } from "@/lib/clean-error";
import { useBoard } from "@/lib/use-board";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <Shell>
      <Board />
    </Shell>
  );
}

function Board() {
  const { view, isLoading, isError, error, refetch, today } = useBoard();
  if (isError) {
    return (
      <div className="flex flex-col gap-3">
        <PageHeader title="Board" />
        <p className="text-sm text-signal">{cleanError(error)}</p>
        <button type="button" className="h-11 text-left text-base font-semibold text-fg" onClick={() => void refetch()}>
          Try again
        </button>
      </div>
    );
  }
  if (isLoading || !view || !today) {
    return (
      <div>
        <PageHeader title="Board" lede="Loading the shop board." />
        <SkeletonBlock />
      </div>
    );
  }

  const hot = view.units
    .filter((unit) => unit.compliance.worst !== "ok" && unit.compliance.worst !== "out")
    .slice(0, 6);
  const todayJobs = view.jobs.filter(
    (job) => job.scheduledOn === today && job.status !== "cancelled",
  );
  const upcoming = view.jobs
    .filter((job) => job.scheduledOn > today && job.status !== "cancelled" && job.status !== "done")
    .slice(0, 4);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Board" lede={`${longDay(today)}. Tags, hydro dates, and the route — same list on every phone.`} />
      <div className="grid grid-cols-3 gap-3">
        <Stat to="/fleet" search={{ view: "attention" }} value={view.counts.attention} label="Attention" />
        <Stat to="/fleet" search={{ view: "due" }} value={view.counts.due} label="Due soon" />
        <Stat to="/fleet" search={{ view: "ok" }} value={view.counts.ok} label="Current" />
      </div>

      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="text-lg font-semibold">Today's route</h2>
          <Link to="/schedule" className="text-sm font-medium text-muted">
            Schedule
          </Link>
        </div>
        {todayJobs.length === 0 ? (
          <p className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">
            Nothing booked today. Open the schedule to put due sites on the route.
          </p>
        ) : (
          todayJobs.map((job) => {
            const site = view.sitesById.get(job.siteId);
            const needing = view.units.filter(
              (unit) =>
                unit.siteId === job.siteId &&
                unit.compliance.worst !== "ok" &&
                unit.compliance.worst !== "out",
            ).length;
            return (
              <Link
                key={job.id}
                to="/job/$id"
                params={{ id: job.id }}
                className="rounded-2xl border border-line bg-surface p-4 transition-colors duration-200 ease-out hover:bg-surface-2"
              >
                <span className="flex items-baseline justify-between gap-3">
                  <span className="text-lg font-semibold">{site?.name ?? "Site"}</span>
                  <span className="text-sm text-muted">{WINDOW_LABEL[job.windowLabel]}</span>
                </span>
                <span className="mt-1 block text-sm text-muted">
                  {job.crew || "Crew not set"}
                  {needing > 0 ? ` · ${needing} need service` : " · tags are current"}
                </span>
              </Link>
            );
          })
        )}
        {upcoming.length > 0 ? (
          <ul className="flex flex-col gap-2">
            {upcoming.map((job) => {
              const site = view.sitesById.get(job.siteId);
              return (
                <li key={job.id}>
                  <Link to="/job/$id" params={{ id: job.id }} className="flex items-baseline justify-between gap-3 text-sm">
                    <span className="text-fg">{site?.name ?? "Site"}</span>
                    <span className="text-muted">
                      {longDay(job.scheduledOn)} · {job.crew || "Unassigned"}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        ) : null}
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="text-lg font-semibold">Needs a tag</h2>
          <Link to="/fleet" search={{ view: "attention" }} className="text-sm font-medium text-muted">
            Fleet
          </Link>
        </div>
        {hot.length === 0 ? (
          <p className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">
            Nothing overdue. The fleet is inside its NFPA windows.
          </p>
        ) : (
          hot.map((unit) => <UnitRow key={unit.id} unit={unit} />)
        )}
      </section>
    </div>
  );
}

function Stat({
  to,
  search,
  value,
  label,
}: {
  to: "/fleet";
  search: { view: "attention" | "due" | "ok" | "out" };
  value: number;
  label: string;
}) {
  return (
    <Link to={to} search={search} className="rounded-2xl border border-line bg-surface p-3">
      <span className="block font-display text-4xl leading-none tabular-nums tracking-wide">{value}</span>
      <span className="mt-2 block text-sm text-muted">{label}</span>
    </Link>
  );
}
