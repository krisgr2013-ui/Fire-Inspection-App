import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { PageHeader, Shell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { cleanError } from "@/lib/clean-error";
import { findCode } from "@/lib/redline.functions";

export const Route = createFileRoute("/scan")({ component: ScanRoute });

type Detector = {
  detect: (source: CanvasImageSource) => Promise<Array<{ rawValue?: string }>>;
};

function ScanRoute() {
  return (
    <Shell>
      <ScanPage />
    </Shell>
  );
}

function ScanPage() {
  const navigate = useNavigate();
  const previewRef = useRef<HTMLVideoElement>(null);
  const stopRef = useRef<(() => void) | null>(null);
  const locked = useRef(false);
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [looking, setLooking] = useState(false);
  const [miss, setMiss] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      stopRef.current?.();
    };
  }, []);

  useEffect(() => {
    if (!cameraOn) return;
    const node = previewRef.current;
    if (!node) return;
    const preview: HTMLVideoElement = node;
    let cancelled = false;
    locked.current = false;

    const stopAll = () => {
      cancelled = true;
      stopRef.current?.();
      stopRef.current = null;
    };

    async function onDetected(raw: string) {
      const next = raw.trim();
      if (!next || locked.current || cancelled) return;
      locked.current = true;
      stopAll();
      setCameraOn(false);
      setCode(next);
      await lookup(next);
    }

    async function start() {
      setCameraError(null);
      let stream: MediaStream | null = null;
      try {
        const DetectorCtor = window.BarcodeDetector;
        if (DetectorCtor) {
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              video: { facingMode: { ideal: "environment" } },
              audio: false,
            });
            if (cancelled) {
              stream.getTracks().forEach((track) => track.stop());
              return;
            }
            preview.srcObject = stream;
            await preview.play();
            const detector: Detector = new DetectorCtor({
              formats: ["code_128", "code_39", "ean_13", "ean_8", "qr_code", "upc_a", "upc_e", "codabar", "itf"],
            });
            const active = stream;
            stopRef.current = () => {
              active.getTracks().forEach((track) => track.stop());
              preview.srcObject = null;
            };
            const tick = async () => {
              if (cancelled || locked.current) return;
              try {
                const codes = await detector.detect(preview);
                const value = codes[0]?.rawValue;
                if (value) {
                  await onDetected(value);
                  return;
                }
              } catch {
                /* frame not ready */
              }
              if (!cancelled && !locked.current) requestAnimationFrame(() => void tick());
            };
            void tick();
            return;
          } catch {
            stream?.getTracks().forEach((track) => track.stop());
            preview.srcObject = null;
          }
        }
        const { BrowserMultiFormatReader } = await import("@zxing/browser");
        if (cancelled) return;
        const reader = new BrowserMultiFormatReader();
        const controls = await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: "environment" } }, audio: false },
          preview,
          (result) => {
            if (result) void onDetected(result.getText());
          },
        );
        if (cancelled) {
          controls.stop();
          return;
        }
        stopRef.current = () => controls.stop();
      } catch (error) {
        if (cancelled) return;
        setCameraOn(false);
        const message = error instanceof Error ? error.message : "";
        setCameraError(
          /denied|permission|notallowed/i.test(message)
            ? "Camera permission was blocked. Type the barcode instead."
            : "Camera isn't available here. Type the barcode or serial.",
        );
      }
    }

    void start();
    return () => {
      cancelled = true;
      stopRef.current?.();
      stopRef.current = null;
    };
  }, [cameraOn]);

  async function lookup(value: string) {
    const trimmed = value.trim();
    if (!trimmed) return;
    setLooking(true);
    setMiss(null);
    setFormError(null);
    try {
      const found = await findCode({ data: { code: trimmed } });
      if (found) {
        await navigate({ to: "/unit/$id", params: { id: found.id } });
        return;
      }
      setMiss(trimmed);
    } catch (error) {
      setFormError(cleanError(error));
    } finally {
      setLooking(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Scan"
        lede="Read the sticker, then keep the serial that's stamped on the cylinder if it's different."
      />
      {cameraOn ? (
        <div className="overflow-hidden rounded-2xl border border-line bg-surface">
          <video ref={previewRef} className="aspect-[3/4] w-full object-cover" muted playsInline autoPlay />
          <div className="p-3">
            <Button variant="quiet" size="block" onClick={() => setCameraOn(false)}>
              Close camera
            </Button>
          </div>
        </div>
      ) : (
        <Button size="block" onClick={() => setCameraOn(true)}>
          Open camera
        </Button>
      )}
      {cameraError ? <p className="text-sm text-muted">{cameraError}</p> : null}
      <form
        className="flex flex-col gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          void lookup(code);
        }}
      >
        <Field label="Barcode or serial">
          <Input
            value={code}
            onChange={(event) => setCode(event.target.value)}
            autoCapitalize="characters"
            autoComplete="off"
            placeholder="RL44190 or CT-44190"
          />
        </Field>
        <Button type="submit" variant="quiet" size="block" disabled={looking || code.trim().length === 0}>
          {looking ? "Looking up…" : "Look up"}
        </Button>
      </form>
      {formError ? <p className="text-sm text-signal">{formError}</p> : null}
      {miss ? (
        <div className="rounded-2xl border border-line bg-surface p-4">
          <p className="text-base font-semibold">No cylinder matches {miss}</p>
          <p className="mt-1 text-sm text-muted text-pretty">
            Add it and set the stamped serial if the sticker is only an asset tag.
          </p>
          <Button asChild size="block" className="mt-4">
            <Link to="/unit/new" search={{ code: miss }}>
              Add this cylinder
            </Link>
          </Button>
        </div>
      ) : null}
    </div>
  );
}

declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => Detector;
  }
}
