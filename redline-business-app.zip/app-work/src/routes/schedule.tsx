import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Select, Textarea } from "@/components/ui/input";
import { cleanError } from "@/lib/clean-error";
import { addDays, formatShort, weekdayShort } from "@/lib/dates";
import { STATUS_LABEL, WINDOW_LABEL } from "@/lib/labels";
import { createJob, scheduleDue } from "@/lib/redline.functions";
import { cn } from "@/lib/cn";
import type { JobWindow, WorkKind } from "@/lib/types";
import { useBoard, useRefresh } from "@/lib/use-board";

export const Route = createFileRoute("/schedule")({ component: ScheduleRoute });

function ScheduleRoute() {
  return (
    <Shell>
      <SchedulePage />
    </Shell>
  );
}

function SchedulePage() {
  const { view, isLoading, isError, error, refetch, today } = useBoard();
  const refresh = useRefresh();
  const navigate = useNavigate();
  const [selected, setSelected] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [siteId, setSiteId] = useState("");
  const [windowLabel, setWindowLabel] = useState<JobWindow>("morning");
  const [notes, setNotes] = useState("");
  const [assignedUserId, setAssignedUserId] = useState("");
  const [workKind, setWorkKind] = useState<WorkKind>("both");

  const day = selected ?? today;

  if (isError) {
    return (
      <div>
        <PageHeader title="Schedule" />
        <p className="text-sm text-signal">{cleanError(error)}</p>
        <button type="button" className="mt-3 h-11 font-semibold" onClick={() => void refetch()}>
          Try again
        </button>
      </div>
    );
  }
  if (isLoading || !view || !today || !day) {
    return (
      <div>
        <PageHeader title="Schedule" lede="Loading the route." />
        <SkeletonBlock />
      </div>
    );
  }

  const days = Array.from({ length: 14 }, (_, index) => addDays(today, index));
  const jobs = view.jobs.filter((job) => job.scheduledOn === day);
  const activeSite = siteId || view.sites[0]?.id || "";

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Schedule"
        lede="Book the sites whose NFPA dates are coming due. The route is shared with every phone on this board."
      />
      <div className="flex gap-2 overflow-x-auto pb-1">
        {days.map((iso) => {
          const count = view.jobs.filter((job) => job.scheduledOn === iso && job.status !== "cancelled").length;
          const on = iso === day;
          return (
            <button
              key={iso}
              type="button"
              onClick={() => setSelected(iso)}
              className={cn(
                "flex h-16 w-14 shrink-0 flex-col items-center justify-center rounded-xl",
                on ? "bg-fg text-bg" : "border border-line bg-surface text-fg",
              )}
            >
              <span className="text-xs font-medium">{weekdayShort(iso)}</span>
              <span className="font-display text-2xl leading-none tabular-nums">{formatShort(iso).split(" ")[1]}</span>
              <span className={cn("text-xs tabular-nums", on ? "text-bg" : "text-faint")}>{count || ""}</span>
            </button>
          );
        })}
      </div>

      {view.role !== "tech" && <div className="flex flex-col gap-2 sm:flex-row">
        <Button
          className="sm:flex-1"
          disabled={pending}
          onClick={async () => {
            setPending(true);
            setMessage(null);
            setFormError(null);
            try {
              const result = await scheduleDue({ data: { today } });
              refresh();
              setMessage(
                result.created === 0
                  ? "Every due site already has a visit in the next 3 weeks."
                  : `Booked ${result.created} ${result.created === 1 ? "site" : "sites"} from the due dates.`,
              );
            } catch (err) {
              setFormError(cleanError(err));
            } finally {
              setPending(false);
            }
          }}
        >
          {pending ? "Booking…" : "Book due sites"}
        </Button>
        <Button variant="quiet" className="sm:flex-1" onClick={() => setOpen((value) => !value)}>
          {open ? "Close" : "New visit"}
        </Button>
      </div>}
      {message ? <p className="text-sm text-muted">{message}</p> : null}
      {formError ? <p className="text-sm text-signal">{formError}</p> : null}

      {open && view.role !== "tech" ? (
        <form
          className="flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4"
          onSubmit={async (event) => {
            event.preventDefault();
            setPending(true);
            setFormError(null);
            try {
              const saved = await createJob({
                data: { siteId: activeSite, scheduledOn: day, windowLabel, assignedUserId, notes, workKind },
              });
              refresh();
              await navigate({ to: "/job/$id", params: { id: saved.id } });
            } catch (err) {
              setFormError(cleanError(err));
              setPending(false);
            }
          }}
        >
          <Field label="Site">
            <Select value={activeSite} onChange={(event) => setSiteId(event.target.value)}>
              {view.sites.map((site) => (
                <option key={site.id} value={site.id}>
                  {site.name}
                </option>
              ))}
            </Select>
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Window">
              <Select value={windowLabel} onChange={(event) => setWindowLabel(event.target.value as JobWindow)}>
                <option value="morning">Morning</option>
                <option value="afternoon">Afternoon</option>
                <option value="day">All day</option>
              </Select>
            </Field>
            <Field label="Assign technician">
              <Select value={assignedUserId} onChange={(event) => setAssignedUserId(event.target.value)}>
                <option value="">Unassigned</option>
                {view.techs.map((tech) => <option key={tech.userId} value={tech.userId}>{tech.name}</option>)}
              </Select>
            </Field>
            <Field label="Work type">
              <Select value={workKind} onChange={(event) => setWorkKind(event.target.value as WorkKind)}>
                <option value="both">Extinguishers + kitchen</option><option value="extinguishers">Extinguishers</option><option value="kitchen">Kitchen systems</option><option value="hydro">Hydro only</option>
              </Select>
            </Field>
          </div>
          <Field label="Notes">
            <Textarea value={notes} onChange={(event) => setNotes(event.target.value)} maxLength={500} />
          </Field>
          <Button type="submit" size="block" disabled={pending || !activeSite}>
            Book {formatShort(day)}
          </Button>
        </form>
      ) : null}

      <section className="flex flex-col gap-2">
        <h2 className="text-lg font-semibold">{formatShort(day)}</h2>
        {jobs.length === 0 ? (
          <p className="rounded-2xl border border-line bg-surface p-4 text-sm text-muted">
            Nothing booked. Use “Book due sites” or add a visit.
          </p>
        ) : (
          jobs.map((job) => {
            const site = view.sitesById.get(job.siteId);
            const needing = view.units.filter(
              (unit) =>
                unit.siteId === job.siteId &&
                unit.compliance.worst !== "ok" &&
                unit.compliance.worst !== "out",
            ).length;
            return (
              <Link
                key={job.id}
                to="/job/$id"
                params={{ id: job.id }}
                className={cn(
                  "rounded-2xl border border-line bg-surface p-4",
                  job.status === "cancelled" && "opacity-60",
                )}
              >
                <span className="flex items-baseline justify-between gap-3">
                  <span className="text-lg font-semibold">{site?.name ?? "Site"}</span>
                  <span className="text-sm text-muted">{STATUS_LABEL[job.status]}</span>
                </span>
                <span className="mt-1 block text-sm text-muted">
                  {WINDOW_LABEL[job.windowLabel]}
                  {job.crew ? ` · ${job.crew}` : ""}
                  {needing > 0 ? ` · ${needing} need service` : ""}
                </span>
              </Link>
            );
          })
        )}
      </section>
    </div>
  );
}
