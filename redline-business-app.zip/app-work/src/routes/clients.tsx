import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { cleanError } from "@/lib/clean-error";
import { saveClient } from "@/lib/redline.functions";
import { useBoard, useRefresh } from "@/lib/use-board";
import type { AccountKind, ClientDraft } from "@/lib/types";

export const Route = createFileRoute("/clients")({ component: ClientsRoute });
const blank: ClientDraft = { name: "", address: "", kind: "mixed", contact: "", annualMonth: "", notes: "" };
function ClientsRoute() {
  return <Shell><ClientsPage /></Shell>;
}
function ClientsPage() {
  const { view, isLoading } = useBoard();
  const refresh = useRefresh();
  const [draft, setDraft] = useState<ClientDraft>(blank);
  const [editing, setEditing] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof ClientDraft>(key: K, value: ClientDraft[K]) => setDraft((old) => ({ ...old, [key]: value }));
  if (isLoading || !view) return <SkeletonBlock />;
  return <div className="flex flex-col gap-4">
    <PageHeader title="Customers" lede="Client locations, contacts, and annual service cycles." />
    {view.role !== "tech" && <Button size="block" onClick={() => { setDraft(blank); setEditing(null); setOpen((v) => !v); }}>{open ? "Close form" : "Add customer"}</Button>}
    {open && view.role !== "tech" && <form className="flex flex-col gap-3 rounded-2xl border border-line bg-surface p-4" onSubmit={async (e) => { e.preventDefault(); setPending(true); setError(null); try { await saveClient({ data: { ...(editing ? { id: editing } : {}), draft } }); refresh(); setDraft(blank); setEditing(null); setOpen(false); } catch (err) { setError(cleanError(err)); } finally { setPending(false); } }}>
      <Field label="Business / site name"><Input value={draft.name} onChange={(e) => set("name", e.target.value)} required maxLength={100} /></Field>
      <Field label="Street address"><Input value={draft.address} onChange={(e) => set("address", e.target.value)} maxLength={240} /></Field>
      <div className="grid grid-cols-2 gap-3"><Field label="Account type"><Select value={draft.kind} onChange={(e) => set("kind", e.target.value as AccountKind)}><option value="mixed">Both</option><option value="extinguishers">Extinguishers</option><option value="kitchen">Kitchen systems</option></Select></Field><Field label="Annual month"><Select value={draft.annualMonth} onChange={(e) => set("annualMonth", e.target.value)}><option value="">Not set</option>{Array.from({length:12},(_,i)=><option key={i+1} value={String(i+1)}>{new Date(2025,i,1).toLocaleString("en-US",{month:"long"})}</option>)}</Select></Field></div>
      <Field label="Primary contact"><Input value={draft.contact} onChange={(e) => set("contact", e.target.value)} maxLength={100} /></Field><Field label="Notes"><Textarea value={draft.notes} onChange={(e) => set("notes", e.target.value)} maxLength={1000} /></Field>
      {error && <p className="text-sm text-signal">{error}</p>}<Button type="submit" size="block" disabled={pending}>{pending ? "Saving…" : "Save customer"}</Button>
    </form>}
    {view.sites.length === 0 ? <p className="rounded-2xl border border-line p-4 text-sm text-muted">No customers yet.</p> : view.sites.map((site) => <article key={site.id} className="rounded-2xl border border-line bg-surface p-4"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><h2 className="text-lg font-semibold">{site.name}</h2><p className="text-sm text-muted">{site.address || "No address"}</p><p className="mt-1 text-xs text-faint">{site.kind} · {site.contact || "No contact"} · {view.units.filter(u=>u.siteId===site.id).length} cylinders · {view.kitchens.filter(k=>k.siteId===site.id).length} kitchen systems</p></div>{view.role !== "tech" && <Button size="sm" variant="quiet" onClick={() => { setDraft({name:site.name,address:site.address,kind:site.kind,contact:site.contact,annualMonth:site.annualMonth ? String(site.annualMonth) : "",notes:site.notes}); setEditing(site.id); setOpen(true); }}>Edit</Button>}</div></article>)}
  </div>;
}
