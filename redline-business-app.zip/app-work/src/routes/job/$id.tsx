import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Shell, SkeletonBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { UnitRow } from "@/components/unit-row";
import { cleanError } from "@/lib/clean-error";
import { formatPretty } from "@/lib/dates";
import { STATUS_LABEL } from "@/lib/labels";
import { updateJob, addLine, removeLine, setJobStatus, clockIn, clockOut } from "@/lib/redline.functions";
import type { JobStatus, JobWindow, WorkKind } from "@/lib/types";
import { useBoard, useRefresh } from "@/lib/use-board";

export const Route = createFileRoute("/job/$id")({ component: JobRoute });

function JobRoute() {
  return (
    <Shell>
      <JobPage />
    </Shell>
  );
}

function JobPage() {
  const { id } = Route.useParams();
  const { view, isLoading } = useBoard();
  const refresh = useRefresh();
  const job = view?.jobs.find((item) => item.id === id);
  const site = job ? view?.sitesById.get(job.siteId) : undefined;
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notes, setNotes] = useState<string | null>(null);
  const [windowLabel, setWindowLabel] = useState<JobWindow | null>(null);
  const [scheduledOn, setScheduledOn] = useState<string | null>(null);
  const [assignedUserId, setAssignedUserId] = useState<string | null>(null);
  const [workKind, setWorkKind] = useState<WorkKind | null>(null);
  const [lineKind, setLineKind] = useState<"part" | "labor">("labor");
  const [description, setDescription] = useState("");
  const [qty, setQty] = useState("1");
  const [rate, setRate] = useState("0");
  const [linePending, setLinePending] = useState(false);
  const [clockPending, setClockPending] = useState(false);

  if (isLoading || !view) return <SkeletonBlock />;
  if (!job || !site) {
    return (
      <div>
        <Link to="/schedule" className="text-sm font-medium text-muted">
          Back to schedule
        </Link>
        <p className="mt-4 text-sm text-muted">That visit is not on the schedule.</p>
      </div>
    );
  }

  const units = view.units.filter((unit) => unit.siteId === site.id);
  const visitId = job.id;
  const notesValue = notes ?? job.notes;
  const windowValue = windowLabel ?? job.windowLabel;
  const dateValue = scheduledOn ?? job.scheduledOn;
  const assignedValue = assignedUserId ?? job.assignedUserId ?? "";
  const workValue = workKind ?? job.workKind;
  const isTech = view.role === "tech";
  const activePunch = view.punches.find((p) => !p.endedAt);

  async function save(status: JobStatus) {
    setPending(true);
    setError(null);
    try {
      await updateJob({
        data: {
          id: visitId,
          scheduledOn: dateValue,
          windowLabel: windowValue,
          assignedUserId: assignedValue,
          status,
          notes: notesValue,
          workKind: workValue,
        },
      });
      refresh();
    } catch (err) {
      setError(cleanError(err));
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <Link to="/schedule" className="text-sm font-medium text-muted">
        Back to schedule
      </Link>
      <PageHeader title={site.name} lede={`${formatPretty(job.scheduledOn)} · ${STATUS_LABEL[job.status]}`} />
      {site.address ? (
        <a
          className="inline-flex min-h-11 items-center text-sm font-semibold"
          href={`https://maps.google.com/maps?q=${encodeURIComponent(site.address)}`}
          target="_blank"
          rel="noreferrer"
        >
          Directions · {site.address}
        </a>
      ) : null}
      {site.notes ? <p className="text-sm text-muted text-pretty">{site.notes}</p> : null}

      <form
        className="flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          void save(job.status);
        }}
      >
        {!isTech && <>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Date">
            <Input type="date" value={dateValue} onChange={(event) => setScheduledOn(event.target.value)} required />
          </Field>
          <Field label="Window">
            <Select value={windowValue} onChange={(event) => setWindowLabel(event.target.value as JobWindow)}>
              <option value="morning">Morning</option>
              <option value="afternoon">Afternoon</option>
              <option value="day">All day</option>
            </Select>
          </Field>
        </div>
        <Field label="Assigned technician">
          <Select value={assignedValue} onChange={(event) => setAssignedUserId(event.target.value)}>
            <option value="">Unassigned</option>{view.techs.map((tech) => <option key={tech.userId} value={tech.userId}>{tech.name}</option>)}
          </Select>
        </Field>
        <Field label="Work type">
          <Select value={workValue} onChange={(event) => setWorkKind(event.target.value as WorkKind)}><option value="both">Extinguishers + kitchen</option><option value="extinguishers">Extinguishers</option><option value="kitchen">Kitchen systems</option><option value="hydro">Hydro only</option></Select>
        </Field>
        <Field label="Notes">
          <Textarea value={notesValue} onChange={(event) => setNotes(event.target.value)} maxLength={500} />
        </Field>
        </>}
        <div className="grid grid-cols-3 gap-2">
          {(["scheduled", "enroute", "done"] as const).map((status) => (
            <Button
              key={status}
              type="button"
              size="sm"
              className="w-full px-2"
              variant={job.status === status ? "primary" : "quiet"}
              disabled={pending}
              onClick={() => { if (isTech) { void setJobStatus({ data: { id: job.id, status } }).then(refresh).catch((err) => setError(cleanError(err))); } else { void save(status); } }}
            >
              {STATUS_LABEL[status]}
            </Button>
          ))}
        </div>
        {!isTech && <Button type="submit" variant="quiet" size="block" disabled={pending}>
          {pending ? "Saving…" : "Save visit"}
        </Button>}
        {!isTech && (job.status !== "cancelled" ? (
          <Button type="button" variant="ghost" size="block" disabled={pending} onClick={() => void save("cancelled")}>
            Cancel visit
          </Button>
        ) : (
          <Button type="button" variant="ghost" size="block" disabled={pending} onClick={() => void save("scheduled")}>
            Restore visit
          </Button>
        ))}
        {isTech && <Button type="button" size="block" disabled={clockPending || Boolean(activePunch)} onClick={async()=>{setClockPending(true);try{await clockIn({data:{kind:"job",jobId:job.id,startedAt:new Date().toISOString()}});refresh()}catch(err){setError(cleanError(err))}finally{setClockPending(false)}}}>{clockPending?"Starting…":activePunch?"Clock out of current task first":"Clock in to this visit"}</Button>}
        {isTech && activePunch && <Button type="button" variant="quiet" size="block" disabled={clockPending} onClick={async()=>{setClockPending(true);try{await clockOut({data:{id:activePunch.id,endedAt:new Date().toISOString()}});refresh()}catch(err){setError(cleanError(err))}finally{setClockPending(false)}}}>{clockPending?"Saving…":"Clock out"}</Button>}
        {error ? <p className="text-sm text-signal">{error}</p> : null}
      </form>

      {!isTech && <section className="flex flex-col gap-3 rounded-2xl border border-line bg-surface p-4">
        <div className="flex items-center justify-between gap-3"><h2 className="text-lg font-semibold">Invoice & work lines</h2><span className="text-sm text-muted">Draft</span></div>
        {(view.lines.filter((line) => line.jobId === job.id)).map((line) => <div key={line.id} className="flex items-center justify-between gap-3 border-t border-line pt-2 text-sm"><div className="min-w-0"><p className="font-medium">{line.description}</p><p className="text-muted">{line.qty} {line.unitLabel} × ${Number(line.rate).toFixed(2)}</p></div><div className="flex items-center gap-3"><strong>${(Number(line.qty)*Number(line.rate)).toFixed(2)}</strong><button type="button" className="text-xs text-signal" onClick={async()=>{await removeLine({data:{id:line.id}});refresh();}}>Remove</button></div></div>)}
        <form className="grid grid-cols-2 gap-2" onSubmit={async(e)=>{e.preventDefault();setLinePending(true);try{await addLine({data:{jobId:job.id,kind:lineKind,description,qty,unitLabel:lineKind==="labor"?"hr":"ea",rate}});setDescription("");refresh();}catch(err){setError(cleanError(err));}finally{setLinePending(false);}}}>
          <Field label="Type"><Select value={lineKind} onChange={e=>setLineKind(e.target.value as "part"|"labor")}><option value="labor">Labor</option><option value="part">Part</option></Select></Field>
          <Field label="Description"><Input value={description} onChange={e=>setDescription(e.target.value)} required maxLength={160} placeholder="Annual service"/></Field>
          <Field label={lineKind==="labor"?"Hours":"Quantity"}><Input type="number" min="0.01" step="0.01" value={qty} onChange={e=>setQty(e.target.value)} required/></Field>
          <Field label={lineKind==="labor"?"Hourly rate ($)":"Unit price ($)"}><Input type="number" min="0" step="0.01" value={rate} onChange={e=>setRate(e.target.value)} required/></Field>
          <Button type="submit" className="col-span-2" disabled={linePending}>{linePending?"Adding…":"Add invoice line"}</Button>
        </form>
        <div className="flex justify-between border-t border-line pt-3 text-base font-semibold"><span>Subtotal</span><span>${view.lines.filter(line=>line.jobId===job.id).reduce((sum,line)=>sum+Number(line.qty)*Number(line.rate),0).toFixed(2)}</span></div>
        <p className="text-xs text-faint">Draft estimate only. Add applicable tax and payment terms before issuing a customer invoice.</p>
      </section>}

      <section className="flex flex-col gap-2">
        <h2 className="text-lg font-semibold">Cylinders on site</h2>
        {units.length === 0 ? (
          <p className="text-sm text-muted">No cylinders at this site yet.</p>
        ) : (
          units.map((unit) => <UnitRow key={unit.id} unit={unit} />)
        )}
      </section>
    </div>
  );
}
