import type {
  AccountKind,
  CleanCadence,
  JobStatus,
  JobWindow,
  KitchenAgent,
  PunchKind,
  ServiceKind,
  ServiceResult,
  WorkKind,
} from "@/lib/types";

export const KIND_LABEL: Record<ServiceKind, string> = {
  monthly: "Monthly",
  annual: "Annual",
  six_year: "6-year",
  hydro: "Hydro",
  recharge: "Recharge",
  semi: "Semi-annual",
  links: "Fusible links",
  cleaning: "Hood cleaning",
};

export const WINDOW_LABEL: Record<JobWindow, string> = {
  morning: "Morning",
  afternoon: "Afternoon",
  day: "All day",
};

export const STATUS_LABEL: Record<JobStatus, string> = {
  scheduled: "Booked",
  enroute: "En route",
  done: "Done",
  cancelled: "Cancelled",
};

export const RESULT_LABEL: Record<ServiceResult, string> = {
  pass: "Pass",
  fail: "Fail",
  compliant: "Compliant",
  deficient: "Deficient",
};

export const WORK_LABEL: Record<WorkKind, string> = {
  extinguishers: "Extinguishers",
  kitchen: "Kitchen suppression",
  both: "Extinguishers and hood",
  hydro: "Hydro / 6-year",
};

export const ACCOUNT_LABEL: Record<AccountKind, string> = {
  extinguishers: "Extinguishers",
  kitchen: "Kitchen suppression",
  mixed: "Extinguishers and hood",
};

export const PUNCH_LABEL: Record<PunchKind, string> = {
  drive: "Driving",
  job: "On the job",
  break: "Break",
};

export const KITCHEN_AGENT_LABEL: Record<KitchenAgent, string> = {
  wet: "Wet chemical",
  dry: "Dry chemical",
  hybrid: "Hybrid",
};

export const CADENCE_LABEL: Record<CleanCadence, string> = {
  monthly: "Monthly",
  quarterly: "Quarterly",
  semiannual: "Semiannual",
  annual: "Annual",
};
