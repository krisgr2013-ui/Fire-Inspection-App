import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useSyncExternalStore } from "react";
import { todayISO } from "@/lib/dates";
import { listBoard } from "@/lib/redline.functions";
import { compliance, worstRank, type Compliance } from "@/lib/nfpa";
import type { Board, Unit } from "@/lib/types";

export function useClientToday(): string | null {
  return useSyncExternalStore(
    () => () => {},
    () => todayISO(),
    () => null,
  );
}

export type DecoratedUnit = Unit & { compliance: Compliance; siteName: string };

export function useBoard() {
  const today = useClientToday();
  const query = useQuery({
    queryKey: ["board"],
    queryFn: () => listBoard({ data: { today: todayISO() } }),
    refetchInterval: 4000,
  });
  const view = useMemo(() => {
    if (!query.data || !today) return null;
    return decorate(query.data, today);
  }, [query.data, today]);
  return { ...query, today, view };
}

export function useRefresh() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: ["board"] });
    void qc.invalidateQueries({ queryKey: ["unit"] });
  };
}

function decorate(board: Board, today: string) {
  const sitesById = new Map(board.sites.map((site) => [site.id, site]));
  const units: DecoratedUnit[] = board.units
    .map((unit) => ({
      ...unit,
      compliance: compliance(unit, today),
      siteName: sitesById.get(unit.siteId)?.name ?? "Unknown site",
    }))
    .sort((a, b) => {
      const rank = worstRank(a.compliance.worst) - worstRank(b.compliance.worst);
      if (rank !== 0) return rank;
      return a.serial.localeCompare(b.serial);
    });
  return {
    ...board,
    sitesById,
    units,
    counts: {
      attention: units.filter(
        (unit) => unit.compliance.worst === "overdue" || unit.compliance.worst === "unknown",
      ).length,
      due: units.filter((unit) => unit.compliance.worst === "due").length,
      ok: units.filter((unit) => unit.compliance.worst === "ok").length,
      out: units.filter((unit) => unit.compliance.worst === "out").length,
    },
  };
}
