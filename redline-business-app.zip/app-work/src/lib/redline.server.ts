import { hashPassword } from "better-auth/crypto";
import { agentOf } from "@/lib/agents";
import { addDays } from "@/lib/dates";
import { demoJobs, demoKitchens, demoUnits, DEMO_SITES } from "@/lib/demo-seed";
import { getSql, type Sql } from "@/lib/db";
import { kitchenCompliance } from "@/lib/kitchen";
import { compliance } from "@/lib/nfpa";
import type {
  AccountKind,
  AgentKey,
  AssetKind,
  Board,
  CleanCadence,
  ClientDraft,
  Condition,
  Job,
  JobLine,
  JobStatus,
  JobWindow,
  Kitchen,
  KitchenAgent,
  KitchenDraft,
  LineKind,
  PhotoPurpose,
  PhotoShot,
  Punch,
  PunchKind,
  RosterTech,
  ServiceEvent,
  ServiceKind,
  ServiceResult,
  ShopRole,
  Site,
  Unit,
  UnitDraft,
  WorkKind,
} from "@/lib/types";

export type Access = {
  userId: string;
  shopId: string;
  role: ShopRole;
  name: string;
};

type SiteRow = {
  id: string;
  name: string;
  address: string;
  notes: string;
  kind: string;
  contact: string;
  annual_month: number | null;
};
type UnitRow = {
  id: string;
  site_id: string;
  serial: string;
  barcode: string;
  agent: string;
  manufacturer: string;
  model: string;
  rating: string;
  capacity: string;
  area: string;
  mount: string;
  manufactured_on: string | null;
  last_monthly: string | null;
  last_annual: string | null;
  last_six_year: string | null;
  last_hydro: string | null;
  condition: string;
  notes: string;
  last_result: string;
};
type JobRow = {
  id: string;
  site_id: string;
  scheduled_on: string;
  window_label: string;
  crew: string;
  status: string;
  notes: string;
  work_kind: string;
  assigned_user_id: string | null;
};
type KitchenRow = {
  id: string;
  site_id: string;
  name: string;
  manufacturer: string;
  model: string;
  agent: string;
  fuel: string;
  cylinders: string;
  nozzles: string;
  links: string;
  location: string;
  cadence: string;
  barcode: string;
  cylinder_serial: string;
  last_semi: string | null;
  last_links: string | null;
  last_hydro: string | null;
  last_cleaning: string | null;
  condition: string;
  notes: string;
  last_result: string;
};
type EventRow = {
  id: string;
  extinguisher_id: string | null;
  kitchen_id: string | null;
  kind: string;
  performed_on: string;
  crew: string;
  result: string;
  notes: string;
};
type LineRow = {
  id: string;
  job_id: string;
  kind: string;
  description: string;
  qty: string;
  unit_label: string;
  rate: string;
};
type PunchRow = {
  id: string;
  crew: string;
  kind: string;
  job_id: string | null;
  started_at: string;
  ended_at: string | null;
};

const ACCOUNT_KINDS = new Set<AccountKind>(["extinguishers", "kitchen", "mixed"]);
const WORK_KINDS = new Set<WorkKind>(["extinguishers", "kitchen", "both", "hydro"]);
const CONDITIONS = new Set<Condition>(["in_service", "out", "condemned"]);
const KINDS = new Set<ServiceKind>([
  "monthly", "annual", "six_year", "hydro", "recharge", "semi", "links", "cleaning",
]);
const RESULTS = new Set<ServiceResult>(["pass", "fail", "compliant", "deficient"]);
const WINDOWS = new Set<JobWindow>(["morning", "afternoon", "day"]);
const STATUSES = new Set<JobStatus>(["scheduled", "enroute", "done", "cancelled"]);
const KITCHEN_AGENTS = new Set<KitchenAgent>(["wet", "dry", "hybrid"]);
const CADENCES = new Set<CleanCadence>(["monthly", "quarterly", "semiannual", "annual"]);
const PURPOSES = new Set<PhotoPurpose>(["hydro", "six_year", "deficiency", "hood"]);

function pick<T extends string>(set: Set<T>, value: string, fallback: T): T {
  return set.has(value as T) ? (value as T) : fallback;
}
function asResult(value: string): ServiceResult {
  if (value === "repaired") return "deficient";
  return pick(RESULTS, value, "pass");
}
function asMonth(value: number | null): number | null {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1 || n > 12) return null;
  return n;
}

function mapSite(row: SiteRow): Site {
  return {
    id: row.id,
    name: row.name,
    address: row.address,
    notes: row.notes,
    kind: pick(ACCOUNT_KINDS, row.kind, "mixed"),
    contact: row.contact,
    annualMonth: asMonth(row.annual_month),
  };
}
function mapUnit(row: UnitRow): Unit {
  return {
    id: row.id,
    siteId: row.site_id,
    serial: row.serial,
    barcode: row.barcode,
    agent: agentOf(row.agent).key as AgentKey,
    manufacturer: row.manufacturer,
    model: row.model,
    rating: row.rating,
    capacity: row.capacity,
    area: row.area,
    mount: row.mount,
    manufacturedOn: row.manufactured_on,
    lastMonthly: row.last_monthly,
    lastAnnual: row.last_annual,
    lastSixYear: row.last_six_year,
    lastHydro: row.last_hydro,
    condition: pick(CONDITIONS, row.condition, "in_service"),
    notes: row.notes,
    lastResult: row.last_result ?? "",
  };
}
function mapJob(row: JobRow): Job {
  return {
    id: row.id,
    siteId: row.site_id,
    scheduledOn: row.scheduled_on,
    windowLabel: pick(WINDOWS, row.window_label, "day"),
    crew: row.crew,
    status: pick(STATUSES, row.status, "scheduled"),
    notes: row.notes,
    workKind: pick(WORK_KINDS, row.work_kind, "both"),
    assignedUserId: row.assigned_user_id,
  };
}
function mapKitchen(row: KitchenRow): Kitchen {
  return {
    id: row.id,
    siteId: row.site_id,
    name: row.name,
    manufacturer: row.manufacturer,
    model: row.model,
    agent: pick(KITCHEN_AGENTS, row.agent, "wet"),
    fuel: row.fuel,
    cylinders: row.cylinders,
    nozzles: row.nozzles,
    links: row.links,
    location: row.location,
    cadence: pick(CADENCES, row.cadence, "semiannual"),
    barcode: row.barcode,
    cylinderSerial: row.cylinder_serial,
    lastSemi: row.last_semi,
    lastLinks: row.last_links,
    lastHydro: row.last_hydro,
    lastCleaning: row.last_cleaning,
    condition: pick(CONDITIONS, row.condition, "in_service"),
    notes: row.notes,
    lastResult: row.last_result ?? "",
  };
}
function mapEvent(row: EventRow): ServiceEvent {
  return {
    id: row.id,
    extinguisherId: row.extinguisher_id,
    kitchenId: row.kitchen_id,
    kind: pick(KINDS, row.kind, "annual"),
    performedOn: row.performed_on,
    crew: row.crew,
    result: asResult(row.result),
    notes: row.notes,
  };
}
function mapLine(row: LineRow): JobLine {
  return {
    id: row.id,
    jobId: row.job_id,
    kind: row.kind === "labor" ? "labor" : "part",
    description: row.description,
    qty: String(row.qty),
    unitLabel: row.unit_label,
    rate: String(row.rate),
  };
}
function mapPunch(row: PunchRow): Punch {
  const kind: PunchKind = row.kind === "drive" || row.kind === "break" ? row.kind : "job";
  return { id: row.id, crew: row.crew, kind, jobId: row.job_id, startedAt: row.started_at, endedAt: row.ended_at };
}

function dateOrNull(value: string): string | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) throw new Error("Use a real date.");
  return trimmed;
}
function later(current: string | null, next: string): string {
  if (!current || next > current) return next;
  return current;
}
function friendly(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (/extinguishers_serial/i.test(message)) throw new Error("That serial is already on a cylinder.");
  if (/barcode/i.test(message)) throw new Error("That barcode is already on another asset.");
  if (/email/i.test(message)) throw new Error("That email already has an account.");
  throw new Error("Could not save. Try again.");
}
function assertController(access: Access) {
  if (access.role !== "controller") throw new Error("Only the controller can do that.");
}

async function loadAccess(userId: string): Promise<Access | null> {
  const sql = await getSql();
  const rows = await sql<{ user_id: string; shop_id: string; role: string; name: string }>`
    select user_id, shop_id, role, name from profiles where user_id = ${userId}
  `;
  const row = rows[0];
  if (!row) return null;
  return { userId, shopId: row.shop_id, role: row.role === "tech" ? "tech" : "controller", name: row.name };
}

async function requireAccess(userId: string): Promise<Access> {
  const access = await loadAccess(userId);
  if (!access) throw new Error("Your account is not on this shop.");
  return access;
}

async function adoptShop(sql: Sql, shopId: string) {
  await sql`update sites set shop_id = ${shopId} where shop_id is null`;
  await sql`update extinguishers set shop_id = ${shopId} where shop_id is null`;
  await sql`update jobs set shop_id = ${shopId} where shop_id is null`;
  await sql`update service_events set shop_id = ${shopId} where shop_id is null`;
  await sql`update kitchen_systems set shop_id = ${shopId} where shop_id is null`;
  await sql`update job_lines set shop_id = ${shopId} where shop_id is null`;
  await sql`update job_photos set shop_id = ${shopId} where shop_id is null`;
  await sql`update punches set shop_id = ${shopId} where shop_id is null`;
}

async function seedShop(sql: Sql, shopId: string, today: string) {
  const existing = await sql<{ id: string }>`select id from sites where shop_id = ${shopId} limit 1`;
  if (existing[0]) return;
  const month = Number(today.slice(5, 7)) || 1;
  const next = month === 12 ? 1 : month + 1;
  const laterMonth = next === 12 ? 1 : next + 1;
  const meta: Record<string, { kind: string; contact: string; annual: number }> = {
    site_cedar: { kind: "mixed", contact: "Kitchen lead", annual: month },
    site_rye: { kind: "extinguishers", contact: "Dock office", annual: next },
    site_pioneer: { kind: "mixed", contact: "Facilities", annual: month },
    site_annex: { kind: "mixed", contact: "School office", annual: laterMonth },
  };
  for (const site of DEMO_SITES) {
    const extra = meta[site.id];
    await sql`
      insert into sites (id, shop_id, name, address, notes, kind, contact, annual_month)
      values (
        ${site.id}, ${shopId}, ${site.name}, ${site.address}, ${site.notes},
        ${extra?.kind ?? "mixed"}, ${extra?.contact ?? ""}, ${extra?.annual ?? null}
      )
      on conflict (id) do nothing
    `;
  }
  for (const unit of demoUnits(today)) {
    await sql`
      insert into extinguishers (
        id, shop_id, site_id, serial, barcode, agent, manufacturer, model, rating, capacity,
        area, mount, manufactured_on, last_monthly, last_annual, last_six_year, last_hydro,
        condition, notes
      ) values (
        ${unit.id}, ${shopId}, ${unit.siteId}, ${unit.serial}, ${unit.barcode}, ${unit.agent},
        ${unit.manufacturer}, ${unit.model}, ${unit.rating}, ${unit.capacity},
        ${unit.area}, ${unit.mount}, ${unit.manufacturedOn}, ${unit.lastMonthly},
        ${unit.lastAnnual}, ${unit.lastSixYear}, ${unit.lastHydro}, ${unit.condition}, ${unit.notes}
      )
      on conflict (id) do nothing
    `;
  }
  for (const hood of demoKitchens(today)) {
    await sql`
      insert into kitchen_systems (
        id, shop_id, site_id, name, manufacturer, model, agent, fuel, cylinders, nozzles, links,
        location, cadence, barcode, cylinder_serial, last_semi, last_links, last_hydro, last_cleaning,
        condition, notes
      ) values (
        ${hood.id}, ${shopId}, ${hood.siteId}, ${hood.name}, ${hood.manufacturer}, ${hood.model},
        ${hood.agent}, ${hood.fuel}, ${hood.cylinders}, ${hood.nozzles}, ${hood.links},
        ${hood.location}, ${hood.cadence}, ${hood.barcode}, ${hood.cylinderSerial},
        ${hood.lastSemi}, ${hood.lastLinks}, ${hood.lastHydro}, ${hood.lastCleaning},
        ${hood.condition}, ${hood.notes}
      )
      on conflict (id) do nothing
    `;
  }
  for (const job of demoJobs(today)) {
    await sql`
      insert into jobs (id, shop_id, site_id, scheduled_on, window_label, crew, status, notes, work_kind)
      values (
        ${job.id}, ${shopId}, ${job.siteId}, ${job.scheduledOn}, ${job.windowLabel},
        '', 'scheduled', ${job.notes}, 'both'
      )
      on conflict (id) do nothing
    `;
  }
}

export async function shopHasAny(): Promise<{ hasShop: boolean }> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`select count(*)::int as n from shops`;
  return { hasShop: Number(rows[0]?.n ?? 0) > 0 };
}

export async function whoAmI(userId: string, today: string) {
  let access = await loadAccess(userId);
  if (!access) {
    const sql = await getSql();
    const shops = await sql<{ id: string }>`select id from shops limit 1`;
    const people = await sql<{ name: string }>`select name from "user" where id = ${userId}`;
    const name = people[0]?.name?.trim() || "Signed in";
    if (shops[0]) return { role: "none" as const, name, userId };
    const shopId = crypto.randomUUID();
    await sql`insert into shops (id, name) values (${shopId}, 'Shop')`;
    await sql`
      insert into profiles (user_id, shop_id, role, name)
      values (${userId}, ${shopId}, 'controller', ${name})
      on conflict (user_id) do nothing
    `;
    // Start with a clean tenant. Legacy preview rows remain unowned and invisible.
    // Re-read after the insert to make concurrent first-login requests idempotent.
    access = await loadAccess(userId);
    if (!access) throw new Error("Could not initialize your shop profile. Please retry.");
  }
  return { role: access.role, name: access.name, userId: access.userId };
}

async function allowedSiteIds(sql: Sql, access: Access): Promise<Set<string> | "all"> {
  if (access.role === "controller") return "all";
  const rows = await sql<{ site_id: string }>`
    select distinct site_id from jobs
    where shop_id = ${access.shopId} and assigned_user_id = ${access.userId} and status <> 'cancelled'
  `;
  return new Set(rows.map((row) => row.site_id));
}
function siteOk(allowed: Set<string> | "all", siteId: string) {
  return allowed === "all" || allowed.has(siteId);
}
async function ownSite(sql: Sql, access: Access, siteId: string): Promise<SiteRow> {
  const rows = await sql<SiteRow>`
    select id, name, address, notes, kind, contact, annual_month
    from sites where id = ${siteId} and shop_id = ${access.shopId}
  `;
  const site = rows[0];
  if (!site) throw new Error("That client is not on your shop.");
  if (!siteOk(await allowedSiteIds(sql, access), site.id)) throw new Error("That client is not on your jobs.");
  return site;
}
async function assertAssignee(sql: Sql, access: Access, assignee: string) {
  if (!assignee) return;
  const rows = await sql<{ user_id: string }>`
    select user_id from profiles where user_id = ${assignee} and shop_id = ${access.shopId}
  `;
  if (!rows[0]) throw new Error("That technician is not on this shop.");
}
async function techName(sql: Sql, access: Access, assignee: string) {
  if (!assignee) return "";
  const rows = await sql<{ name: string }>`
    select name from profiles where user_id = ${assignee} and shop_id = ${access.shopId}
  `;
  return rows[0]?.name ?? "";
}

async function readBoard(sql: Sql, access: Access): Promise<Board> {
  const allowed = await allowedSiteIds(sql, access);
  const sites = (await sql<SiteRow>`
    select id, name, address, notes, kind, contact, annual_month
    from sites where shop_id = ${access.shopId} order by name
  `).filter((row) => siteOk(allowed, row.id));
  const siteIds = new Set(sites.map((row) => row.id));
  const units = (await sql<UnitRow>`
    select id, site_id, serial, barcode, agent, manufacturer, model, rating, capacity,
           area, mount, manufactured_on, last_monthly, last_annual, last_six_year,
           last_hydro, condition, notes, last_result
    from extinguishers where shop_id = ${access.shopId} order by serial
  `).filter((row) => siteIds.has(row.site_id));
  const kitchens = (await sql<KitchenRow>`
    select id, site_id, name, manufacturer, model, agent, fuel, cylinders, nozzles, links,
           location, cadence, barcode, cylinder_serial, last_semi, last_links, last_hydro,
           last_cleaning, condition, notes, last_result
    from kitchen_systems where shop_id = ${access.shopId} order by name
  `).filter((row) => siteIds.has(row.site_id));
  const jobs = (await sql<JobRow>`
    select id, site_id, scheduled_on, window_label, crew, status, notes, work_kind, assigned_user_id
    from jobs where shop_id = ${access.shopId} order by scheduled_on, id
  `).filter((row) => access.role === "controller" || row.assigned_user_id === access.userId);
  const jobIds = new Set(jobs.map((row) => row.id));
  const assetIds = new Set([...units.map((unit) => unit.id), ...kitchens.map((unit) => unit.id)]);
  const events = (await sql<EventRow>`
    select id, extinguisher_id, kitchen_id, kind, performed_on, crew, result, notes
    from service_events where shop_id = ${access.shopId} order by performed_on desc, created_at desc
  `).filter((event) => assetIds.has(event.extinguisher_id ?? "") || assetIds.has(event.kitchen_id ?? "")).map(mapEvent);
  const lines = (await sql<LineRow>`
    select id, job_id, kind, description, qty, unit_label, rate
    from job_lines where shop_id = ${access.shopId} order by created_at
  `).filter((row) => jobIds.has(row.job_id)).map(mapLine);
  const punchRows = access.role === "controller"
    ? await sql<PunchRow>`
        select id, crew, kind, job_id, started_at, ended_at from punches
        where shop_id = ${access.shopId} order by started_at desc limit 60
      `
    : await sql<PunchRow>`
        select id, crew, kind, job_id, started_at, ended_at from punches
        where shop_id = ${access.shopId} and user_id = ${access.userId}
        order by started_at desc limit 40
      `;
  const roster = await sql<{ user_id: string; name: string }>`
    select user_id, name from profiles where shop_id = ${access.shopId} order by name
  `;
  const techs: RosterTech[] = roster
    .filter((row) => access.role === "controller" || row.user_id === access.userId)
    .map((row) => ({ userId: row.user_id, name: row.name }));
  const counts = await sql<{ job_id: string; n: number }>`
    select job_id, count(*)::int as n from job_photos where shop_id = ${access.shopId} group by job_id
  `;
  return {
    role: access.role,
    sites: sites.map(mapSite),
    units: units.map(mapUnit),
    kitchens: kitchens.map(mapKitchen),
    jobs: jobs.map(mapJob),
    events,
    lines,
    punches: punchRows.map(mapPunch),
    techs,
    photoCounts: counts.filter((row) => jobIds.has(row.job_id)).map((row) => ({ jobId: row.job_id, count: Number(row.n) })),
  };
}

export async function listBoard(userId: string, today: string): Promise<Board> {
  await whoAmI(userId, today);
  return readBoard(await getSql(), await requireAccess(userId));
}

export async function getUnit(userId: string, id: string) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const units = await sql<UnitRow>`
    select id, site_id, serial, barcode, agent, manufacturer, model, rating, capacity,
           area, mount, manufactured_on, last_monthly, last_annual, last_six_year,
           last_hydro, condition, notes, last_result
    from extinguishers where id = ${id} and shop_id = ${access.shopId}
  `;
  const unit = units[0];
  if (!unit) throw new Error("That cylinder is not on your jobs.");
  const site = await ownSite(sql, access, unit.site_id);
  const events = await sql<EventRow>`
    select id, extinguisher_id, kitchen_id, kind, performed_on, crew, result, notes
    from service_events where extinguisher_id = ${id} and shop_id = ${access.shopId}
    order by performed_on desc, created_at desc
  `;
  return { unit: mapUnit(unit), site: mapSite(site), events: events.map(mapEvent) };
}

export async function getKitchen(userId: string, id: string) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const rows = await sql<KitchenRow>`
    select id, site_id, name, manufacturer, model, agent, fuel, cylinders, nozzles, links,
           location, cadence, barcode, cylinder_serial, last_semi, last_links, last_hydro,
           last_cleaning, condition, notes, last_result
    from kitchen_systems where id = ${id} and shop_id = ${access.shopId}
  `;
  const kitchen = rows[0];
  if (!kitchen) throw new Error("That system is not on your jobs.");
  const site = await ownSite(sql, access, kitchen.site_id);
  const events = await sql<EventRow>`
    select id, extinguisher_id, kitchen_id, kind, performed_on, crew, result, notes
    from service_events where kitchen_id = ${id} and shop_id = ${access.shopId}
    order by performed_on desc, created_at desc
  `;
  return { kitchen: mapKitchen(kitchen), site: mapSite(site), events: events.map(mapEvent) };
}

export async function findCode(userId: string, code: string) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const trimmed = code.trim();
  if (!trimmed) return { status: "miss" as const };
  const units = await sql<{ id: string; site_id: string }>`
    select id, site_id from extinguishers
    where shop_id = ${access.shopId}
      and (lower(serial) = lower(${trimmed}) or (barcode <> '' and lower(barcode) = lower(${trimmed})))
    limit 1
  `;
  const hoods = units[0]
    ? []
    : await sql<{ id: string; site_id: string }>`
        select id, site_id from kitchen_systems
        where shop_id = ${access.shopId}
          and (
            (barcode <> '' and lower(barcode) = lower(${trimmed}))
            or (cylinder_serial <> '' and lower(cylinder_serial) = lower(${trimmed}))
          )
        limit 1
      `;
  const hit = units[0]
    ? { id: units[0].id, siteId: units[0].site_id, kind: "extinguisher" as const }
    : hoods[0]
      ? { id: hoods[0].id, siteId: hoods[0].site_id, kind: "kitchen" as const }
      : null;
  if (!hit) return { status: "miss" as const };
  if (!siteOk(await allowedSiteIds(sql, access), hit.siteId)) return { status: "locked" as const };
  return { status: "hit" as const, id: hit.id, kind: hit.kind };
}

async function resolveSite(sql: Sql, access: Access, draft: { siteId: string; newSiteName: string; newSiteAddress: string }) {
  const name = draft.newSiteName.trim();
  if (name) {
    assertController(access);
    const id = crypto.randomUUID();
    await sql`
      insert into sites (id, shop_id, name, address, notes)
      values (${id}, ${access.shopId}, ${name}, ${draft.newSiteAddress.trim()}, '')
    `;
    return id;
  }
  if (!draft.siteId) throw new Error("Pick a client.");
  await ownSite(sql, access, draft.siteId);
  return draft.siteId;
}

export async function createUnit(userId: string, draft: UnitDraft): Promise<{ id: string }> {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const siteId = await resolveSite(sql, access, draft);
  const id = crypto.randomUUID();
  try {
    await sql`
      insert into extinguishers (
        id, shop_id, site_id, serial, barcode, agent, manufacturer, model, rating, capacity,
        area, mount, manufactured_on, last_monthly, last_annual, last_six_year, last_hydro,
        condition, notes
      ) values (
        ${id}, ${access.shopId}, ${siteId}, ${draft.serial.trim().toUpperCase()}, ${draft.barcode.trim()},
        ${draft.agent}, ${draft.manufacturer.trim()}, ${draft.model.trim()}, ${draft.rating.trim()},
        ${draft.capacity.trim()}, ${draft.area.trim()}, ${draft.mount.trim()},
        ${dateOrNull(draft.manufacturedOn)}, ${dateOrNull(draft.lastMonthly)}, ${dateOrNull(draft.lastAnnual)},
        ${dateOrNull(draft.lastSixYear)}, ${dateOrNull(draft.lastHydro)}, ${draft.condition}, ${draft.notes.trim()}
      )
    `;
  } catch (error) {
    friendly(error);
  }
  return { id };
}

export async function updateUnit(userId: string, id: string, draft: UnitDraft): Promise<{ id: string }> {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const existing = await sql<{ site_id: string }>`
    select site_id from extinguishers where id = ${id} and shop_id = ${access.shopId}
  `;
  if (!existing[0]) throw new Error("That cylinder is not on your jobs.");
  await ownSite(sql, access, existing[0].site_id);
  const siteId = await resolveSite(sql, access, draft);
  try {
    await sql`
      update extinguishers set
        site_id = ${siteId}, serial = ${draft.serial.trim().toUpperCase()}, barcode = ${draft.barcode.trim()},
        agent = ${draft.agent}, manufacturer = ${draft.manufacturer.trim()}, model = ${draft.model.trim()},
        rating = ${draft.rating.trim()}, capacity = ${draft.capacity.trim()}, area = ${draft.area.trim()},
        mount = ${draft.mount.trim()}, manufactured_on = ${dateOrNull(draft.manufacturedOn)},
        last_monthly = ${dateOrNull(draft.lastMonthly)}, last_annual = ${dateOrNull(draft.lastAnnual)},
        last_six_year = ${dateOrNull(draft.lastSixYear)}, last_hydro = ${dateOrNull(draft.lastHydro)},
        condition = ${draft.condition}, notes = ${draft.notes.trim()}, updated_at = now()
      where id = ${id} and shop_id = ${access.shopId}
    `;
  } catch (error) {
    friendly(error);
  }
  return { id };
}

export async function removeUnit(userId: string, id: string) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  const rows = await sql<{ id: string }>`
    delete from extinguishers where id = ${id} and shop_id = ${access.shopId} returning id
  `;
  if (!rows[0]) throw new Error("That cylinder is not on your shop.");
  return { ok: true as const };
}

export async function recordService(userId: string, input: {
  unitId: string; kind: ServiceKind; performedOn: string; crew: string; result: ServiceResult; notes: string;
}) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const performed = dateOrNull(input.performedOn);
  if (!performed) throw new Error("Enter the date the work was done.");
  const units = await sql<UnitRow>`
    select id, site_id, serial, barcode, agent, manufacturer, model, rating, capacity,
           area, mount, manufactured_on, last_monthly, last_annual, last_six_year,
           last_hydro, condition, notes, last_result
    from extinguishers where id = ${input.unitId} and shop_id = ${access.shopId}
  `;
  const unit = units[0];
  if (!unit) throw new Error("That cylinder is not on your jobs.");
  await ownSite(sql, access, unit.site_id);
  const agent = agentOf(unit.agent);
  let lastMonthly = unit.last_monthly;
  let lastAnnual = unit.last_annual;
  let lastSix = unit.last_six_year;
  let lastHydro = unit.last_hydro;
  if (input.kind === "monthly") lastMonthly = later(lastMonthly, performed);
  if (input.kind === "annual") lastAnnual = later(lastAnnual, performed);
  if (input.kind === "six_year") lastSix = later(lastSix, performed);
  if (input.kind === "hydro") {
    lastHydro = later(lastHydro, performed);
    if (agent.sixYear) lastSix = later(lastSix, performed);
  }
  const id = crypto.randomUUID();
  await sql`
    insert into service_events (id, shop_id, extinguisher_id, kind, performed_on, crew, result, notes)
    values (${id}, ${access.shopId}, ${input.unitId}, ${input.kind}, ${performed}, ${input.crew.trim() || access.name}, ${input.result}, ${input.notes.trim()})
  `;
  await sql`
    update extinguishers set
      last_monthly = ${lastMonthly}, last_annual = ${lastAnnual}, last_six_year = ${lastSix},
      last_hydro = ${lastHydro}, last_result = ${input.result}, updated_at = now()
    where id = ${input.unitId} and shop_id = ${access.shopId}
  `;
  return { id };
}

export async function saveClient(userId: string, input: { id?: string; draft: ClientDraft }) {
  const access = await requireAccess(userId);
  assertController(access);
  const name = input.draft.name.trim();
  if (!name) throw new Error("Name the client.");
  const month = input.draft.annualMonth ? Number(input.draft.annualMonth) : null;
  if (month !== null && (!Number.isInteger(month) || month < 1 || month > 12)) throw new Error("Pick the annual month.");
  const sql = await getSql();
  if (input.id) {
    const rows = await sql<{ id: string }>`
      update sites set
        name = ${name}, address = ${input.draft.address.trim()}, notes = ${input.draft.notes.trim()},
        kind = ${input.draft.kind}, contact = ${input.draft.contact.trim()}, annual_month = ${month}
      where id = ${input.id} and shop_id = ${access.shopId} returning id
    `;
    if (!rows[0]) throw new Error("That client is not on your shop.");
    return { id: input.id };
  }
  const id = crypto.randomUUID();
  await sql`
    insert into sites (id, shop_id, name, address, notes, kind, contact, annual_month)
    values (${id}, ${access.shopId}, ${name}, ${input.draft.address.trim()}, ${input.draft.notes.trim()}, ${input.draft.kind}, ${input.draft.contact.trim()}, ${month})
  `;
  return { id };
}

export async function saveKitchen(userId: string, input: { id?: string; draft: KitchenDraft }) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  await ownSite(sql, access, input.draft.siteId);
  const name = input.draft.name.trim();
  if (!name) throw new Error("Name the system.");
  const draft = input.draft;
  const dates = {
    lastSemi: dateOrNull(draft.lastSemi),
    lastLinks: dateOrNull(draft.lastLinks),
    lastHydro: dateOrNull(draft.lastHydro),
    lastCleaning: dateOrNull(draft.lastCleaning),
  };
  if (input.id) {
    const existing = await sql<{ id: string }>`select id from kitchen_systems where id = ${input.id} and shop_id = ${access.shopId}`;
    if (!existing[0]) throw new Error("That system is not on your jobs.");
    try {
      await sql`
        update kitchen_systems set
          site_id = ${draft.siteId}, name = ${name}, manufacturer = ${draft.manufacturer.trim()},
          model = ${draft.model.trim()}, agent = ${draft.agent}, fuel = ${draft.fuel.trim()},
          cylinders = ${draft.cylinders.trim()}, nozzles = ${draft.nozzles.trim()}, links = ${draft.links.trim()},
          location = ${draft.location.trim()}, cadence = ${draft.cadence}, barcode = ${draft.barcode.trim()},
          cylinder_serial = ${draft.cylinderSerial.trim().toUpperCase()},
          last_semi = ${dates.lastSemi}, last_links = ${dates.lastLinks}, last_hydro = ${dates.lastHydro},
          last_cleaning = ${dates.lastCleaning}, condition = ${draft.condition}, notes = ${draft.notes.trim()},
          updated_at = now()
        where id = ${input.id} and shop_id = ${access.shopId}
      `;
    } catch (error) {
      friendly(error);
    }
    return { id: input.id };
  }
  const id = crypto.randomUUID();
  try {
    await sql`
      insert into kitchen_systems (
        id, shop_id, site_id, name, manufacturer, model, agent, fuel, cylinders, nozzles, links,
        location, cadence, barcode, cylinder_serial, last_semi, last_links, last_hydro, last_cleaning,
        condition, notes
      ) values (
        ${id}, ${access.shopId}, ${draft.siteId}, ${name}, ${draft.manufacturer.trim()}, ${draft.model.trim()},
        ${draft.agent}, ${draft.fuel.trim()}, ${draft.cylinders.trim()}, ${draft.nozzles.trim()}, ${draft.links.trim()},
        ${draft.location.trim()}, ${draft.cadence}, ${draft.barcode.trim()}, ${draft.cylinderSerial.trim().toUpperCase()},
        ${dates.lastSemi}, ${dates.lastLinks}, ${dates.lastHydro}, ${dates.lastCleaning}, ${draft.condition}, ${draft.notes.trim()}
      )
    `;
  } catch (error) {
    friendly(error);
  }
  return { id };
}

export async function removeKitchen(userId: string, id: string) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  await sql`delete from service_events where kitchen_id = ${id} and shop_id = ${access.shopId}`;
  const rows = await sql<{ id: string }>`
    delete from kitchen_systems where id = ${id} and shop_id = ${access.shopId} returning id
  `;
  if (!rows[0]) throw new Error("That system is not on your shop.");
  return { ok: true as const };
}

export async function recordKitchen(userId: string, input: {
  kitchenId: string; kind: ServiceKind; performedOn: string; crew: string; result: ServiceResult; notes: string;
}) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const performed = dateOrNull(input.performedOn);
  if (!performed) throw new Error("Enter the date the work was done.");
  const rows = await sql<KitchenRow>`
    select id, site_id, name, manufacturer, model, agent, fuel, cylinders, nozzles, links,
           location, cadence, barcode, cylinder_serial, last_semi, last_links, last_hydro,
           last_cleaning, condition, notes, last_result
    from kitchen_systems where id = ${input.kitchenId} and shop_id = ${access.shopId}
  `;
  const kitchen = rows[0];
  if (!kitchen) throw new Error("That system is not on your jobs.");
  await ownSite(sql, access, kitchen.site_id);
  let lastSemi = kitchen.last_semi;
  let lastLinks = kitchen.last_links;
  let lastHydro = kitchen.last_hydro;
  let lastCleaning = kitchen.last_cleaning;
  if (input.kind === "semi") lastSemi = later(lastSemi, performed);
  if (input.kind === "links") lastLinks = later(lastLinks, performed);
  if (input.kind === "hydro") lastHydro = later(lastHydro, performed);
  if (input.kind === "cleaning") lastCleaning = later(lastCleaning, performed);
  const id = crypto.randomUUID();
  await sql`
    insert into service_events (id, shop_id, kitchen_id, kind, performed_on, crew, result, notes)
    values (${id}, ${access.shopId}, ${input.kitchenId}, ${input.kind}, ${performed}, ${input.crew.trim() || access.name}, ${input.result}, ${input.notes.trim()})
  `;
  await sql`
    update kitchen_systems set
      last_semi = ${lastSemi}, last_links = ${lastLinks}, last_hydro = ${lastHydro},
      last_cleaning = ${lastCleaning}, last_result = ${input.result}, updated_at = now()
    where id = ${input.kitchenId} and shop_id = ${access.shopId}
  `;
  return { id };
}

async function loadVisibleJob(sql: Sql, access: Access, id: string) {
  const rows = await sql<JobRow>`
    select id, site_id, scheduled_on, window_label, crew, status, notes, work_kind, assigned_user_id
    from jobs where id = ${id} and shop_id = ${access.shopId}
  `;
  const job = rows[0];
  if (!job) throw new Error("That visit is not on your jobs.");
  if (access.role === "tech" && job.assigned_user_id !== access.userId) {
    throw new Error("That visit is assigned to someone else.");
  }
  return job;
}

export async function createJob(userId: string, input: {
  siteId: string; scheduledOn: string; windowLabel: JobWindow; assignedUserId: string; notes: string; workKind: WorkKind;
}) {
  const access = await requireAccess(userId);
  assertController(access);
  const when = dateOrNull(input.scheduledOn);
  if (!when) throw new Error("Pick a date.");
  const sql = await getSql();
  const sites = await sql<{ id: string }>`select id from sites where id = ${input.siteId} and shop_id = ${access.shopId}`;
  if (!sites[0]) throw new Error("Pick a client.");
  await assertAssignee(sql, access, input.assignedUserId);
  const crew = await techName(sql, access, input.assignedUserId);
  const id = crypto.randomUUID();
  await sql`
    insert into jobs (id, shop_id, site_id, scheduled_on, window_label, crew, status, notes, work_kind, assigned_user_id)
    values (
      ${id}, ${access.shopId}, ${input.siteId}, ${when}, ${input.windowLabel}, ${crew}, 'scheduled',
      ${input.notes.trim()}, ${input.workKind}, ${input.assignedUserId || null}
    )
  `;
  return { id };
}

export async function updateJob(userId: string, input: {
  id: string; scheduledOn: string; windowLabel: JobWindow; assignedUserId: string; status: JobStatus; notes: string; workKind: WorkKind;
}) {
  const access = await requireAccess(userId);
  assertController(access);
  const when = dateOrNull(input.scheduledOn);
  if (!when) throw new Error("Pick a date.");
  const sql = await getSql();
  await assertAssignee(sql, access, input.assignedUserId);
  const crew = await techName(sql, access, input.assignedUserId);
  const rows = await sql<{ id: string }>`
    update jobs set
      scheduled_on = ${when}, window_label = ${input.windowLabel}, crew = ${crew}, status = ${input.status},
      notes = ${input.notes.trim()}, work_kind = ${input.workKind}, assigned_user_id = ${input.assignedUserId || null}
    where id = ${input.id} and shop_id = ${access.shopId} returning id
  `;
  if (!rows[0]) throw new Error("That visit is not on your shop.");
  return { id: input.id };
}

export async function setJobStatus(userId: string, id: string, status: JobStatus) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  await loadVisibleJob(sql, access, id);
  await sql`update jobs set status = ${status} where id = ${id} and shop_id = ${access.shopId}`;
  return { id };
}

async function bookJob(sql: Sql, access: Access, siteId: string, when: string, workKind: WorkKind, notes: string) {
  await sql`
    insert into jobs (id, shop_id, site_id, scheduled_on, window_label, crew, status, notes, work_kind)
    values (${crypto.randomUUID()}, ${access.shopId}, ${siteId}, ${when}, 'day', '', 'scheduled', ${notes}, ${workKind})
  `;
}

function dueStamp(report: { worst: string; clocks: { state: string; next: string | null }[] }, today: string, earliest: string | null) {
  let next = earliest;
  let needs = false;
  if (report.worst === "overdue" || report.worst === "due" || report.worst === "unknown") {
    needs = true;
    for (const clock of report.clocks) {
      if (clock.state === "overdue" || clock.state === "unknown") next = today;
      else if (clock.state === "due" && clock.next && next !== today && (!next || clock.next < next)) next = clock.next;
    }
  }
  return { needs, earliest: next };
}

export async function scheduleDue(userId: string, today: string) {
  const access = await requireAccess(userId);
  assertController(access);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(today)) throw new Error("Pick a date.");
  const sql = await getSql();
  const board = await readBoard(sql, access);
  const until = addDays(today, 21);
  const booked = new Set(
    board.jobs.filter((job) => (job.status === "scheduled" || job.status === "enroute") && job.scheduledOn >= today && job.scheduledOn <= until).map((job) => job.siteId),
  );
  let created = 0;
  for (const site of board.sites) {
    if (booked.has(site.id)) continue;
    let earliest: string | null = null;
    let needsUnit = false;
    let needsHood = false;
    for (const unit of board.units) {
      if (unit.siteId !== site.id) continue;
      const stamp = dueStamp(compliance(unit, today), today, earliest);
      if (stamp.needs) needsUnit = true;
      earliest = stamp.earliest;
    }
    for (const kitchen of board.kitchens) {
      if (kitchen.siteId !== site.id) continue;
      const stamp = dueStamp(kitchenCompliance(kitchen, today), today, earliest);
      if (stamp.needs) needsHood = true;
      earliest = stamp.earliest;
    }
    if ((!needsUnit && !needsHood) || !earliest) continue;
    const workKind: WorkKind = needsUnit && needsHood ? "both" : needsHood ? "kitchen" : "extinguishers";
    await bookJob(sql, access, site.id, earliest < today ? today : earliest, workKind, "Booked from NFPA due dates.");
    created += 1;
  }
  return { created };
}

export async function scheduleAnnual(userId: string, today: string) {
  const access = await requireAccess(userId);
  assertController(access);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(today)) throw new Error("Pick a date.");
  const month = Number(today.slice(5, 7));
  const sql = await getSql();
  const board = await readBoard(sql, access);
  const until = addDays(today, 35);
  const booked = new Set(
    board.jobs.filter((job) => job.status !== "cancelled" && job.scheduledOn >= today && job.scheduledOn <= until).map((job) => job.siteId),
  );
  let created = 0;
  for (const site of board.sites) {
    if (site.annualMonth !== month || booked.has(site.id)) continue;
    const workKind: WorkKind = site.kind === "kitchen" ? "kitchen" : site.kind === "extinguishers" ? "extinguishers" : "both";
    await bookJob(sql, access, site.id, today, workKind, "Annual inspection");
    created += 1;
  }
  return { created };
}

export async function listTechs(userId: string) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  const rows = await sql<{ user_id: string; name: string; email: string }>`
    select p.user_id, p.name, u.email from profiles p
    join "user" u on u.id = p.user_id
    where p.shop_id = ${access.shopId} and p.role = 'tech' order by p.name
  `;
  return rows.map((row) => ({ userId: row.user_id, name: row.name, email: row.email }));
}

export async function createTech(userId: string, input: { name: string; email: string; password: string }) {
  const access = await requireAccess(userId);
  assertController(access);
  const name = input.name.trim();
  const email = input.email.trim().toLowerCase();
  if (name.length < 2) throw new Error("Enter the technician's name.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Enter a real email.");
  if (input.password.length < 8 || input.password.length > 72) throw new Error("Password needs 8 to 72 characters.");
  const sql = await getSql();
  const id = crypto.randomUUID();
  const hash = await hashPassword(input.password);
  try {
    await sql`
      insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
      values (${id}, ${name}, ${email}, true, now(), now())
    `;
    await sql`
      insert into "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
      values (${crypto.randomUUID()}, ${id}, 'credential', ${id}, ${hash}, now(), now())
    `;
    await sql`insert into profiles (user_id, shop_id, role, name) values (${id}, ${access.shopId}, 'tech', ${name})`;
  } catch (error) {
    friendly(error);
  }
  return { userId: id };
}

export async function addLine(userId: string, input: {
  jobId: string; kind: LineKind; description: string; qty: string; unitLabel: string; rate: string;
}) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  await loadVisibleJob(sql, access, input.jobId);
  const description = input.description.trim();
  if (!description) throw new Error("Pick a part or a labor line.");
  const qty = Number(input.qty);
  const rate = Number(input.rate);
  if (!Number.isFinite(qty) || qty <= 0 || qty > 99) throw new Error("Pick a quantity.");
  if (!Number.isFinite(rate) || rate < 0 || rate > 9999) throw new Error("Pick a rate.");
  const id = crypto.randomUUID();
  await sql`
    insert into job_lines (id, shop_id, job_id, kind, description, qty, unit_label, rate)
    values (${id}, ${access.shopId}, ${input.jobId}, ${input.kind}, ${description}, ${qty}, ${input.unitLabel === "hr" ? "hr" : "ea"}, ${rate})
  `;
  return { id };
}

export async function removeLine(userId: string, id: string) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  const rows = await sql<{ job_id: string }>`select job_id from job_lines where id = ${id} and shop_id = ${access.shopId}`;
  if (!rows[0]) throw new Error("That line is already gone.");
  await loadVisibleJob(sql, access, rows[0].job_id);
  await sql`delete from job_lines where id = ${id} and shop_id = ${access.shopId}`;
  return { ok: true as const };
}

export async function listPhotos(userId: string, jobId: string): Promise<PhotoShot[]> {
  const access = await requireAccess(userId);
  const sql = await getSql();
  await loadVisibleJob(sql, access, jobId);
  const rows = await sql<{
    id: string; job_id: string; asset_id: string; asset_kind: string; purpose: string; caption: string; image: string;
  }>`
    select id, job_id, asset_id, asset_kind, purpose, caption, image
    from job_photos where job_id = ${jobId} and shop_id = ${access.shopId} order by created_at
  `;
  return rows.map((row) => ({
    id: row.id,
    jobId: row.job_id,
    assetId: row.asset_id,
    assetKind: row.asset_kind === "kitchen" ? "kitchen" : "extinguisher",
    purpose: pick(PURPOSES, row.purpose, "hydro"),
    caption: row.caption,
    image: row.image,
  }));
}

export async function addPhoto(userId: string, input: {
  jobId: string; assetId: string; assetKind: AssetKind; purpose: PhotoPurpose; caption: string; image: string;
}) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const job = await loadVisibleJob(sql, access, input.jobId);
  if (!input.image.startsWith("data:image/jpeg;base64,") || input.image.length > 280_000) {
    throw new Error("That photo is too large. Retake it closer.");
  }
  const count = await sql<{ n: number }>`
    select count(*)::int as n from job_photos where job_id = ${input.jobId} and shop_id = ${access.shopId}
  `;
  if (Number(count[0]?.n ?? 0) >= 8) throw new Error("This job already has 8 photos.");
  if (input.assetId) {
    const tableOk = input.assetKind === "kitchen"
      ? await sql<{ id: string }>`select id from kitchen_systems where id = ${input.assetId} and site_id = ${job.site_id} and shop_id = ${access.shopId}`
      : await sql<{ id: string }>`select id from extinguishers where id = ${input.assetId} and site_id = ${job.site_id} and shop_id = ${access.shopId}`;
    if (!tableOk[0]) throw new Error("Pick an asset on this client.");
  }
  const id = crypto.randomUUID();
  await sql`
    insert into job_photos (id, shop_id, job_id, asset_id, asset_kind, purpose, caption, image)
    values (${id}, ${access.shopId}, ${input.jobId}, ${input.assetId}, ${input.assetKind}, ${input.purpose}, ${input.caption.trim()}, ${input.image})
  `;
  return { id };
}

export async function removePhoto(userId: string, id: string) {
  const access = await requireAccess(userId);
  const sql = await getSql();
  const rows = await sql<{ job_id: string }>`select job_id from job_photos where id = ${id} and shop_id = ${access.shopId}`;
  if (!rows[0]) throw new Error("That photo is already gone.");
  await loadVisibleJob(sql, access, rows[0].job_id);
  await sql`delete from job_photos where id = ${id} and shop_id = ${access.shopId}`;
  return { ok: true as const };
}

export async function clockIn(userId: string, input: { kind: PunchKind; jobId: string; startedAt: string }) {
  const access = await requireAccess(userId);
  if (access.role !== "tech") throw new Error("Clock in on the technician account.");
  if (!/^\d{4}-\d{2}-\d{2}T/.test(input.startedAt)) throw new Error("Bad clock time.");
  const sql = await getSql();
  const open = await sql<{ id: string }>`
    select id from punches where user_id = ${access.userId} and shop_id = ${access.shopId} and ended_at is null limit 1
  `;
  if (open[0]) throw new Error("Clock out before starting another punch.");
  let jobId: string | null = null;
  if (input.kind !== "break" || input.jobId) {
    if (!input.jobId) throw new Error("Pick the job.");
    await loadVisibleJob(sql, access, input.jobId);
    jobId = input.jobId;
  }
  const id = crypto.randomUUID();
  await sql`
    insert into punches (id, shop_id, user_id, crew, kind, job_id, started_at)
    values (${id}, ${access.shopId}, ${access.userId}, ${access.name}, ${input.kind}, ${jobId}, ${input.startedAt})
  `;
  if (jobId && input.kind === "drive") {
    await sql`update jobs set status = 'enroute' where id = ${jobId} and shop_id = ${access.shopId} and status = 'scheduled'`;
  }
  return { id };
}

export async function clockOut(userId: string, input: { id: string; endedAt: string }) {
  const access = await requireAccess(userId);
  if (!/^\d{4}-\d{2}-\d{2}T/.test(input.endedAt)) throw new Error("Bad clock time.");
  const sql = await getSql();
  const rows = await sql<{ id: string }>`
    update punches set ended_at = ${input.endedAt}
    where id = ${input.id} and user_id = ${access.userId} and shop_id = ${access.shopId} and ended_at is null
    returning id
  `;
  if (!rows[0]) throw new Error("That punch is already closed.");
  return { ok: true as const };
}


export type InvoiceStatus = "draft" | "sent" | "paid" | "void";
const INVOICE_STATUSES = new Set<InvoiceStatus>(["draft", "sent", "paid", "void"]);
export async function listInvoices(userId: string) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  const rows = await sql<{ id: string; job_id: string; invoice_number: string; bill_to_name: string; bill_to_address: string; bill_to_contact: string; status: string; issued_on: string; due_on: string | null; tax_rate: string; notes: string; paid_on: string | null }>`
    select i.id, i.job_id, i.invoice_number, i.bill_to_name, i.bill_to_address, i.bill_to_contact, i.status, i.issued_on, i.due_on, i.tax_rate, i.notes, i.paid_on
    from invoices i join jobs j on j.id = i.job_id
    where i.shop_id = ${access.shopId} order by i.issued_on desc, i.created_at desc
  `;
  const result = [];
  for (const row of rows) {
    const lines = await sql<{ id: string; description: string; qty: string; unit_label: string; rate: string }>`
      select id, description, qty, unit_label, rate from invoice_lines where invoice_id = ${row.id} order by id
    `;
    result.push({ id: row.id, jobId: row.job_id, invoiceNumber: row.invoice_number, status: pick(INVOICE_STATUSES, row.status, "draft"), issuedOn: row.issued_on, dueOn: row.due_on, taxRate: String(row.tax_rate), notes: row.notes, paidOn: row.paid_on, siteName: row.bill_to_name, address: row.bill_to_address, contact: row.bill_to_contact, lines: lines.map(line => ({ id: line.id, description: line.description, qty: String(line.qty), unitLabel: line.unit_label, rate: String(line.rate) })) });
  }
  return result;
}

export async function createInvoice(userId: string, input: { jobId: string; dueOn: string; taxRate: string; notes: string }) {
  const access = await requireAccess(userId);
  assertController(access);
  const sql = await getSql();
  const job = await loadVisibleJob(sql, access, input.jobId);
  if (job.status !== "done") throw new Error("Complete the service visit before invoicing it.");
  const taxRate = Number(input.taxRate);
  if (!Number.isFinite(taxRate) || taxRate < 0 || taxRate > 20) throw new Error("Tax rate must be between 0 and 20%.");
  const dueOn = dateOrNull(input.dueOn);
  const lines = await sql<{ description: string; qty: string; unit_label: string; rate: string }>`
    select description, qty, unit_label, rate from job_lines where job_id = ${job.id} and shop_id = ${access.shopId} order by created_at
  `;
  if (lines.length === 0) throw new Error("Add at least one work or parts line before creating an invoice.");
  const clientRows = await sql<{ name: string; address: string; contact: string }>`select name, address, contact from sites where id = ${job.site_id} and shop_id = ${access.shopId}`;
  const client = clientRows[0];
  if (!client) throw new Error("That customer is no longer available.");
  const id = crypto.randomUUID();
  const invoiceNumber = `RL-${new Date().toISOString().slice(0,10).replaceAll("-", "")}-${crypto.randomUUID().slice(0,6).toUpperCase()}`;
  const issuedOn = new Date().toISOString().slice(0,10);
  await sql`insert into invoices (id, shop_id, job_id, invoice_number, bill_to_name, bill_to_address, bill_to_contact, status, issued_on, due_on, tax_rate, notes) values (${id}, ${access.shopId}, ${job.id}, ${invoiceNumber}, ${client.name}, ${client.address}, ${client.contact}, 'draft', ${issuedOn}, ${dueOn}, ${taxRate}, ${input.notes.trim()})`;
  for (const line of lines) await sql`insert into invoice_lines (id, invoice_id, description, qty, unit_label, rate) values (${crypto.randomUUID()}, ${id}, ${line.description}, ${Number(line.qty)}, ${line.unit_label}, ${Number(line.rate)})`;
  return { id, invoiceNumber };
}

export async function updateInvoiceStatus(userId: string, input: { id: string; status: InvoiceStatus; paidOn: string }) {
  const access = await requireAccess(userId);
  assertController(access);
  const paidOn = input.status === "paid" ? (dateOrNull(input.paidOn) ?? new Date().toISOString().slice(0,10)) : null;
  const sql = await getSql();
  const currentRows = await sql<{ status: string }>`select status from invoices where id = ${input.id} and shop_id = ${access.shopId}`;
  const current = currentRows[0]?.status;
  if (!current) throw new Error("That invoice is not on your shop.");
  if (current === "paid" || current === "void") throw new Error("Paid or void invoices are locked.");
  if (current === "draft" && input.status === "paid") throw new Error("Mark the invoice sent before marking it paid.");
  if (input.status === "draft") throw new Error("An issued invoice cannot return to draft.");
  await sql`update invoices set status = ${input.status}, paid_on = ${paidOn} where id = ${input.id} and shop_id = ${access.shopId}`;
  return { id: input.id };
}
