import { useSyncExternalStore } from "react";
import type { ShopRole } from "@/lib/types";

const ROLE_KEY = "redline-role";
const CREW_KEY = "redline-crew";

let role: ShopRole | null = null;
let roleReady = false;
const roleSubs = new Set<() => void>();

function readRole(): ShopRole | null {
  try {
    const value = localStorage.getItem(ROLE_KEY);
    return value === "tech" || value === "controller" ? value : null;
  } catch {
    return null;
  }
}

function emitRole() {
  for (const fn of roleSubs) fn();
}

export function setShopRole(next: ShopRole | null) {
  try {
    if (next) localStorage.setItem(ROLE_KEY, next);
    else localStorage.removeItem(ROLE_KEY);
  } catch {
    /* private mode */
  }
  role = next;
  roleReady = true;
  emitRole();
}

export function useShopRole(): { ready: boolean; role: ShopRole | null } {
  return useSyncExternalStore(
    (cb) => {
      roleSubs.add(cb);
      return () => roleSubs.delete(cb);
    },
    () => {
      if (!roleReady) {
        role = readRole();
        roleReady = true;
      }
      return { ready: true, role };
    },
    () => ({ ready: false, role: null }),
  );
}

let crew = "";
let crewReady = false;
const crewSubs = new Set<() => void>();

function emitCrew() {
  for (const fn of crewSubs) fn();
}

export function setCrewName(next: string) {
  crew = next;
  crewReady = true;
  try {
    localStorage.setItem(CREW_KEY, next);
  } catch {
    /* private mode */
  }
  emitCrew();
}

export function useCrewName(): string {
  return useSyncExternalStore(
    (cb) => {
      crewSubs.add(cb);
      return () => crewSubs.delete(cb);
    },
    () => {
      if (!crewReady) {
        try {
          crew = localStorage.getItem(CREW_KEY) ?? "";
        } catch {
          crew = "";
        }
        crewReady = true;
      }
      return crew;
    },
    () => "",
  );
}
