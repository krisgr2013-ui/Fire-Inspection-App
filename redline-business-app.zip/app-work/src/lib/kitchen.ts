import { addDays, addMonths, addYears } from "@/lib/dates";
import type { Clock, ClockState, Compliance } from "@/lib/nfpa";
import type { Kitchen } from "@/lib/types";

const SOON = { semi: 30, links: 30, hydro: 90, cleaning: 14 } as const;

const CADENCE_MONTHS = {
  monthly: 1,
  quarterly: 3,
  semiannual: 6,
  annual: 12,
} as const;

function stateFor(next: string | null, today: string, soonDays: number): ClockState {
  if (!next) return "unknown";
  if (next < today) return "overdue";
  if (next <= addDays(today, soonDays)) return "due";
  return "ok";
}

export function kitchenCompliance(
  system: Pick<
    Kitchen,
    "condition" | "cadence" | "lastSemi" | "lastLinks" | "lastHydro" | "lastCleaning"
  >,
  today: string,
): Compliance {
  const cleanMonths = CADENCE_MONTHS[system.cadence] ?? 6;
  const clocks: Clock[] = [
    {
      key: "semi",
      label: "Semi-annual maintenance",
      cite: "NFPA 17A §7.3",
      last: system.lastSemi,
      next: system.lastSemi ? addMonths(system.lastSemi, 6) : null,
      state: "ok",
      note: "Wet-chemical systems are serviced at least every six months.",
    },
    {
      key: "links",
      label: "Fusible links",
      cite: "NFPA 17A §7.5",
      last: system.lastLinks,
      next: system.lastLinks ? addYears(system.lastLinks, 1) : null,
      state: "ok",
      note: "Replace fusible links at least annually.",
    },
    {
      key: "cleaning",
      label: "Hood cleaning",
      cite: "NFPA 96",
      last: system.lastCleaning,
      next: system.lastCleaning ? addMonths(system.lastCleaning, cleanMonths) : null,
      state: "ok",
      note: `Cleaning cadence on this account is ${system.cadence}.`,
    },
    {
      key: "hydro",
      label: "Cylinder hydrostatic",
      cite: "NFPA 17A · 12-year cylinder",
      last: system.lastHydro,
      next: system.lastHydro ? addYears(system.lastHydro, 12) : null,
      state: "ok",
      note: system.lastHydro ? "" : "No hydrostatic date on the agent cylinder.",
    },
  ];

  for (const clock of clocks) {
    const soon = SOON[clock.key as keyof typeof SOON] ?? 30;
    clock.state = stateFor(clock.next, today, soon);
  }

  if (system.condition !== "in_service") {
    return {
      clocks,
      worst: "out",
      headline: system.condition === "condemned" ? "Condemned" : "Out of service",
    };
  }

  const rank: Record<ClockState, number> = { overdue: 4, unknown: 3, due: 2, ok: 1, na: 0 };
  let best = clocks[0];
  for (const clock of clocks) {
    if (rank[clock.state] > rank[best.state]) best = clock;
  }

  let headline = "In service";
  if (best.state === "overdue") headline = `${best.label} overdue`;
  else if (best.state === "unknown") headline = `${best.label} not on file`;
  else if (best.state === "due") headline = `${best.label} due soon`;

  const worst = clocks.some((clock) => clock.state === "overdue")
    ? "overdue"
    : clocks.some((clock) => clock.state === "unknown")
      ? "unknown"
      : clocks.some((clock) => clock.state === "due")
        ? "due"
        : "ok";

  return { clocks, worst, headline };
}

export function cadenceLabel(cadence: CleanCadence): string {
  if (cadence === "semiannual") return "Semiannual";
  if (cadence === "quarterly") return "Quarterly";
  if (cadence === "monthly") return "Monthly";
  return "Annual";
}
