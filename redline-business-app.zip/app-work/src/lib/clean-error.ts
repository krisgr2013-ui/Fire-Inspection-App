export function cleanError(error: unknown): string {
  if (!(error instanceof Error) || !error.message) return "Something went wrong. Try again.";
  const message = error.message.trim();
  if (message.startsWith("[") || message.startsWith("{")) return "Check the form and try again.";
  if (/duplicate key|extinguishers_serial/i.test(message)) {
    return "That serial is already on the board.";
  }
  if (/extinguishers_barcode/i.test(message)) return "That barcode is already on another cylinder.";
  if (/^Failed query|^select |^insert |^update /i.test(message)) return "Could not save. Try again.";
  return message;
}
