export function directionsUrl(address: string): string {
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address.trim())}`;
}

export function lineTotal(qty: string, rate: string): number {
  const n = Number(qty) * Number(rate);
  return Number.isFinite(n) ? n : 0;
}

export function money(amount: number): string {
  return amount.toLocaleString("en-US", { style: "currency", currency: "USD" });
}
