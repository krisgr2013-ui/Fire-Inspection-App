import { addDays, addMonths } from "@/lib/dates";
import type { CleanCadence, Condition, JobWindow, KitchenAgent, UnitDraft } from "@/lib/types";

export type SeedSite = { id: string; name: string; address: string; notes: string };

export type SeedUnit = {
  id: string;
  siteId: string;
  serial: string;
  barcode: string;
  agent: UnitDraft["agent"];
  manufacturer: string;
  model: string;
  rating: string;
  capacity: string;
  area: string;
  mount: string;
  manufacturedOn: string | null;
  lastMonthly: string | null;
  lastAnnual: string | null;
  lastSixYear: string | null;
  lastHydro: string | null;
  condition: Condition;
  notes: string;
};

export type SeedJob = {
  id: string;
  siteId: string;
  scheduledOn: string;
  windowLabel: JobWindow;
  crew: string;
  notes: string;
};

export const DEMO_SITES: SeedSite[] = [
  {
    id: "site_cedar",
    name: "Cedar Table",
    address: "1400 W University Way, Ellensburg, WA",
    notes: "Kitchen hood and dining room. Avoid the lunch rush.",
  },
  {
    id: "site_rye",
    name: "Rye Creek Warehouse",
    address: "80 Logistics Ln, Ellensburg, WA",
    notes: "Dock doors face the yard. Clean-agent unit is on the office mezzanine.",
  },
  {
    id: "site_pioneer",
    name: "Pioneer Medical",
    address: "2500 N Monroe St, Ellensburg, WA",
    notes: "Clinic stays open during the visit. Class K is in the staff kitchen.",
  },
  {
    id: "site_annex",
    name: "Capitol Annex School",
    address: "900 E Capitol Ave, Ellensburg, WA",
    notes: "Check in at the office. Gym cylinder is on the east wall.",
  },
];

export function demoUnits(today: string): SeedUnit[] {
  const m = (n: number) => addMonths(today, n);
  const shift = (months: number, days: number) => addDays(addMonths(today, months), days);
  return [
    {
      id: "unit_ct_kitchen",
      siteId: "site_cedar",
      serial: "CT-44190",
      barcode: "RL44190",
      agent: "abc",
      manufacturer: "Amerex",
      model: "B402",
      rating: "3-A:40-B:C",
      capacity: "5 lb",
      area: "Kitchen",
      mount: "Beside the pass window",
      manufacturedOn: m(-48),
      lastMonthly: addDays(today, -12),
      lastAnnual: m(-13),
      lastSixYear: m(-48),
      lastHydro: m(-48),
      condition: "in_service",
      notes: "Barcode sticker is RL44190. Serial is stamped on the skirt.",
    },
    {
      id: "unit_ct_elec",
      siteId: "site_cedar",
      serial: "CT-21880",
      barcode: "CT-21880",
      agent: "co2",
      manufacturer: "Badger",
      model: "B10V",
      rating: "10-B:C",
      capacity: "10 lb",
      area: "Electrical room",
      mount: "Left of the panel",
      manufacturedOn: m(-70),
      lastMonthly: addDays(today, -6),
      lastAnnual: m(-4),
      lastSixYear: null,
      lastHydro: shift(-60, 18),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_ct_mist",
      siteId: "site_cedar",
      serial: "CT-33002",
      barcode: "CT-33002",
      agent: "mist",
      manufacturer: "Ansul",
      model: "Cleanguard",
      rating: "2-A:C",
      capacity: "2.5 gal",
      area: "Server closet",
      mount: "Inside the door",
      manufacturedOn: m(-30),
      lastMonthly: addDays(today, -5),
      lastAnnual: m(-3),
      lastSixYear: null,
      lastHydro: m(-8),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_ct_patio",
      siteId: "site_cedar",
      serial: "CT-11802",
      barcode: "CT-11802",
      agent: "bc",
      manufacturer: "Kidde",
      model: "Pro 10",
      rating: "40-B:C",
      capacity: "10 lb",
      area: "Patio storage",
      mount: "On the floor, do not hang",
      manufacturedOn: m(-120),
      lastMonthly: null,
      lastAnnual: m(-20),
      lastSixYear: m(-90),
      lastHydro: m(-90),
      condition: "condemned",
      notes: "Shell failed visual. Do not recharge.",
    },
    {
      id: "unit_rc_dock",
      siteId: "site_rye",
      serial: "RC-10021",
      barcode: "RC-10021",
      agent: "abc",
      manufacturer: "Amerex",
      model: "B456",
      rating: "4-A:80-B:C",
      capacity: "20 lb",
      area: "Loading dock",
      mount: "Column B4, ladder needed",
      manufacturedOn: m(-96),
      lastMonthly: addDays(today, -8),
      lastAnnual: m(-3),
      lastSixYear: m(-84),
      lastHydro: m(-84),
      condition: "in_service",
      notes: "6-year internal was skipped at the last annual.",
    },
    {
      id: "unit_rc_mezz",
      siteId: "site_rye",
      serial: "RC-10088",
      barcode: "RC-10088",
      agent: "clean",
      manufacturer: "Ansul",
      model: "Cleanguard FE13",
      rating: "2-A:10-B:C",
      capacity: "13 lb",
      area: "Office mezzanine",
      mount: "By the server rack",
      manufacturedOn: null,
      lastMonthly: addDays(today, -4),
      lastAnnual: m(-6),
      lastSixYear: null,
      lastHydro: null,
      condition: "in_service",
      notes: "No manufacture date and no hydro stamp in the file.",
    },
    {
      id: "unit_rc_aisle",
      siteId: "site_rye",
      serial: "RC-33014",
      barcode: "RC-33014",
      agent: "abc",
      manufacturer: "Badger",
      model: "Advantage 10",
      rating: "4-A:60-B:C",
      capacity: "10 lb",
      area: "Aisle 3",
      mount: "Mid rack, south end",
      manufacturedOn: m(-36),
      lastMonthly: m(-2),
      lastAnnual: m(-4),
      lastSixYear: m(-24),
      lastHydro: m(-24),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_rc_pk",
      siteId: "site_rye",
      serial: "RC-44100",
      barcode: "RC-44100",
      agent: "purplek",
      manufacturer: "Amerex",
      model: "C260",
      rating: "60-B:C",
      capacity: "20 lb",
      area: "Flammable cage",
      mount: "Outside the cage door",
      manufacturedOn: m(-80),
      lastMonthly: addDays(today, -9),
      lastAnnual: m(-2),
      lastSixYear: shift(-72, 50),
      lastHydro: shift(-72, 50),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_pm_k",
      siteId: "site_pioneer",
      serial: "PM-55002",
      barcode: "PM-55002",
      agent: "k",
      manufacturer: "Ansul",
      model: "Red Line K",
      rating: "2-A:K",
      capacity: "6 L",
      area: "Staff kitchen",
      mount: "Right of the hood",
      manufacturedOn: m(-40),
      lastMonthly: addDays(today, -3),
      lastAnnual: shift(-12, 10),
      lastSixYear: null,
      lastHydro: m(-20),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_pm_hall",
      siteId: "site_pioneer",
      serial: "PM-55019",
      barcode: "PM-55019",
      agent: "abc",
      manufacturer: "Kidde",
      model: "Pro 5",
      rating: "3-A:40-B:C",
      capacity: "5 lb",
      area: "West hallway",
      mount: "Pulled from the hook",
      manufacturedOn: m(-60),
      lastMonthly: m(-3),
      lastAnnual: m(-8),
      lastSixYear: m(-36),
      lastHydro: m(-36),
      condition: "out",
      notes: "Dented skirt. Replacement is on the truck.",
    },
    {
      id: "unit_pm_co2",
      siteId: "site_pioneer",
      serial: "PM-77210",
      barcode: "PM-77210",
      agent: "co2",
      manufacturer: "Badger",
      model: "B5V",
      rating: "5-B:C",
      capacity: "5 lb",
      area: "Imaging closet",
      mount: "Behind the door",
      manufacturedOn: m(-28),
      lastMonthly: addDays(today, -6),
      lastAnnual: m(-2),
      lastSixYear: null,
      lastHydro: m(-18),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_ca_gym",
      siteId: "site_annex",
      serial: "CA-88001",
      barcode: "CA-88001",
      agent: "water",
      manufacturer: "Amerex",
      model: "240",
      rating: "2-A",
      capacity: "2.5 gal",
      area: "Gym",
      mount: "East wall, by the bleachers",
      manufacturedOn: m(-80),
      lastMonthly: addDays(today, -9),
      lastAnnual: m(-5),
      lastSixYear: null,
      lastHydro: m(-72),
      condition: "in_service",
      notes: "Hydrostatic test lapsed. Leave it in place until the shop can test it.",
    },
    {
      id: "unit_ca_kitchen",
      siteId: "site_annex",
      serial: "CA-88014",
      barcode: "CA-88014",
      agent: "k",
      manufacturer: "Ansul",
      model: "K-Guard",
      rating: "2-A:K",
      capacity: "6 L",
      area: "Cafeteria",
      mount: "End of the cook line",
      manufacturedOn: m(-26),
      lastMonthly: addDays(today, -2),
      lastAnnual: m(-1),
      lastSixYear: null,
      lastHydro: m(-12),
      condition: "in_service",
      notes: "",
    },
    {
      id: "unit_ca_lab",
      siteId: "site_annex",
      serial: "CA-90211",
      barcode: "CA-90211",
      agent: "abc_ss",
      manufacturer: "Amerex",
      model: "B402S",
      rating: "2-A:10-B:C",
      capacity: "5 lb",
      area: "Science lab",
      mount: "Stainless cabinet, right door",
      manufacturedOn: m(-64),
      lastMonthly: addDays(today, -11),
      lastAnnual: m(-6),
      lastSixYear: null,
      lastHydro: shift(-60, 36),
      condition: "in_service",
      notes: "Stainless shell. 5-year hydro, not the 12-year cycle.",
    },
  ];
}

export function demoJobs(today: string): SeedJob[] {
  return [
    {
      id: "job_cedar_today",
      siteId: "site_cedar",
      scheduledOn: today,
      windowLabel: "morning",
      crew: "Truck 1",
      notes: "Kitchen annual is late. CO2 in the electrical room is coming due for hydro.",
    },
    {
      id: "job_rye_next",
      siteId: "site_rye",
      scheduledOn: addDays(today, 1),
      windowLabel: "day",
      crew: "Truck 2",
      notes: "Dock 6-year is late. Mezzanine clean-agent has no hydro date.",
    },
    {
      id: "job_pioneer",
      siteId: "site_pioneer",
      scheduledOn: addDays(today, 3),
      windowLabel: "morning",
      crew: "Truck 1",
      notes: "Class K annual window opens this visit.",
    },
  ];
}

export type SeedKitchen = {
  id: string;
  siteId: string;
  name: string;
  manufacturer: string;
  model: string;
  agent: KitchenAgent;
  fuel: string;
  cylinders: string;
  nozzles: string;
  links: string;
  location: string;
  cadence: CleanCadence;
  barcode: string;
  cylinderSerial: string;
  lastSemi: string | null;
  lastLinks: string | null;
  lastHydro: string | null;
  lastCleaning: string | null;
  condition: Condition;
  notes: string;
};

export function demoKitchens(today: string): SeedKitchen[] {
  const m = (n: number) => addMonths(today, n);
  return [
    {
      id: "hood_cedar",
      siteId: "site_cedar",
      name: "Cook line",
      manufacturer: "Ansul",
      model: "R-102",
      agent: "wet",
      fuel: "Gas",
      cylinders: "1",
      nozzles: "8",
      links: "6",
      location: "Main hood",
      cadence: "quarterly",
      barcode: "HOOD-CT-1",
      cylinderSerial: "ANS-22910",
      lastSemi: m(-8),
      lastLinks: m(-14),
      lastHydro: m(-36),
      lastCleaning: m(-4),
      condition: "in_service",
      notes: "Fusible links are past the annual change.",
    },
    {
      id: "hood_pioneer",
      siteId: "site_pioneer",
      name: "Staff kitchen",
      manufacturer: "Ansul",
      model: "R-102",
      agent: "wet",
      fuel: "Electric",
      cylinders: "1",
      nozzles: "4",
      links: "3",
      location: "Staff kitchen",
      cadence: "semiannual",
      barcode: "HOOD-PM-1",
      cylinderSerial: "ANS-44012",
      lastSemi: m(-2),
      lastLinks: m(-4),
      lastHydro: m(-20),
      lastCleaning: m(-2),
      condition: "in_service",
      notes: "",
    },
    {
      id: "hood_annex",
      siteId: "site_annex",
      name: "Cafeteria",
      manufacturer: "Range Guard",
      model: "K-Guard",
      agent: "wet",
      fuel: "Gas",
      cylinders: "2",
      nozzles: "10",
      links: "8",
      location: "Cook line",
      cadence: "quarterly",
      barcode: "HOOD-CA-1",
      cylinderSerial: "RG-88014",
      lastSemi: m(-5),
      lastLinks: m(-11),
      lastHydro: m(-24),
      lastCleaning: m(-2),
      condition: "in_service",
      notes: "",
    },
  ];
}
