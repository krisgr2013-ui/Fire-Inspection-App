export const AGENT_KEYS = [
  "abc",
  "abc_ss",
  "bc",
  "purplek",
  "co2",
  "water",
  "mist",
  "foam",
  "k",
  "clean",
  "classd",
] as const;

export type AgentKey = (typeof AGENT_KEYS)[number];
export type Condition = "in_service" | "out" | "condemned";
export type ServiceKind =
  | "monthly"
  | "annual"
  | "six_year"
  | "hydro"
  | "recharge"
  | "semi"
  | "links"
  | "cleaning";
export type ServiceResult = "pass" | "fail" | "compliant" | "deficient";
export type JobWindow = "morning" | "afternoon" | "day";
export type JobStatus = "scheduled" | "enroute" | "done" | "cancelled";
export type AccountKind = "extinguishers" | "kitchen" | "mixed";
export type WorkKind = "extinguishers" | "kitchen" | "both" | "hydro";
export type KitchenAgent = "wet" | "dry" | "hybrid";
export type CleanCadence = "monthly" | "quarterly" | "semiannual" | "annual";
export type ShopRole = "tech" | "controller";
export type PunchKind = "drive" | "job" | "break";
export type LineKind = "part" | "labor";
export type PhotoPurpose = "hydro" | "six_year" | "deficiency" | "hood";
export type AssetKind = "extinguisher" | "kitchen";

export type Site = {
  id: string;
  name: string;
  address: string;
  notes: string;
  kind: AccountKind;
  contact: string;
  annualMonth: number | null;
};

export type Unit = {
  id: string;
  siteId: string;
  serial: string;
  barcode: string;
  agent: AgentKey;
  manufacturer: string;
  model: string;
  rating: string;
  capacity: string;
  area: string;
  mount: string;
  manufacturedOn: string | null;
  lastMonthly: string | null;
  lastAnnual: string | null;
  lastSixYear: string | null;
  lastHydro: string | null;
  condition: Condition;
  notes: string;
  lastResult: string;
};

export type Kitchen = {
  id: string;
  siteId: string;
  name: string;
  manufacturer: string;
  model: string;
  agent: KitchenAgent;
  fuel: string;
  cylinders: string;
  nozzles: string;
  links: string;
  location: string;
  cadence: CleanCadence;
  barcode: string;
  cylinderSerial: string;
  lastSemi: string | null;
  lastLinks: string | null;
  lastHydro: string | null;
  lastCleaning: string | null;
  condition: Condition;
  notes: string;
  lastResult: string;
};

export type Job = {
  id: string;
  siteId: string;
  scheduledOn: string;
  windowLabel: JobWindow;
  crew: string;
  status: JobStatus;
  notes: string;
  workKind: WorkKind;
  assignedUserId: string | null;
};

export type ServiceEvent = {
  id: string;
  extinguisherId: string | null;
  kitchenId: string | null;
  kind: ServiceKind;
  performedOn: string;
  crew: string;
  result: ServiceResult;
  notes: string;
};

export type JobLine = {
  id: string;
  jobId: string;
  kind: LineKind;
  description: string;
  qty: string;
  unitLabel: string;
  rate: string;
};

export type Punch = {
  id: string;
  crew: string;
  kind: PunchKind;
  jobId: string | null;
  startedAt: string;
  endedAt: string | null;
};

export type PhotoShot = {
  id: string;
  jobId: string;
  assetId: string;
  assetKind: AssetKind;
  purpose: PhotoPurpose;
  caption: string;
  image: string;
};

export type RosterTech = {
  userId: string;
  name: string;
};

export type Board = {
  role: ShopRole;
  sites: Site[];
  units: Unit[];
  kitchens: Kitchen[];
  jobs: Job[];
  events: ServiceEvent[];
  lines: JobLine[];
  punches: Punch[];
  techs: RosterTech[];
  photoCounts: { jobId: string; count: number }[];
};

export type UnitDraft = {
  siteId: string;
  newSiteName: string;
  newSiteAddress: string;
  serial: string;
  barcode: string;
  agent: AgentKey;
  manufacturer: string;
  model: string;
  rating: string;
  capacity: string;
  area: string;
  mount: string;
  manufacturedOn: string;
  lastMonthly: string;
  lastAnnual: string;
  lastSixYear: string;
  lastHydro: string;
  condition: Condition;
  notes: string;
};

export type ClientDraft = {
  name: string;
  address: string;
  kind: AccountKind;
  contact: string;
  annualMonth: string;
  notes: string;
};

export type KitchenDraft = {
  siteId: string;
  name: string;
  manufacturer: string;
  model: string;
  agent: KitchenAgent;
  fuel: string;
  cylinders: string;
  nozzles: string;
  links: string;
  location: string;
  cadence: CleanCadence;
  barcode: string;
  cylinderSerial: string;
  lastSemi: string;
  lastLinks: string;
  lastHydro: string;
  lastCleaning: string;
  condition: Condition;
  notes: string;
};
