import type { AgentKey } from "@/lib/types";

export type Agent = {
  key: AgentKey;
  label: string;
  plate: string;
  classes: string;
  hydroYears: 5 | 12;
  sixYear: boolean;
  shell: string;
};

/** NFPA 10 Table 8.3.1 hydrostatic intervals, plus the 6-year internal rule. */
export const AGENTS: Record<AgentKey, Agent> = {
  abc: {
    key: "abc",
    label: "ABC dry chemical",
    plate: "ABC",
    classes: "A · B · C",
    hydroYears: 12,
    sixYear: true,
    shell: "Stored pressure, mild steel",
  },
  abc_ss: {
    key: "abc_ss",
    label: "ABC dry chemical, stainless",
    plate: "ABC",
    classes: "A · B · C",
    hydroYears: 5,
    sixYear: false,
    shell: "Stored pressure, stainless shell",
  },
  bc: {
    key: "bc",
    label: "BC dry chemical",
    plate: "BC",
    classes: "B · C",
    hydroYears: 12,
    sixYear: true,
    shell: "Stored pressure, mild steel",
  },
  purplek: {
    key: "purplek",
    label: "Purple-K dry chemical",
    plate: "PK",
    classes: "B · C",
    hydroYears: 12,
    sixYear: true,
    shell: "Stored pressure, mild steel",
  },
  co2: {
    key: "co2",
    label: "Carbon dioxide",
    plate: "CO2",
    classes: "B · C",
    hydroYears: 5,
    sixYear: false,
    shell: "Cylinder",
  },
  water: {
    key: "water",
    label: "Water",
    plate: "A",
    classes: "A",
    hydroYears: 5,
    sixYear: false,
    shell: "Stored pressure",
  },
  mist: {
    key: "mist",
    label: "Water mist",
    plate: "WM",
    classes: "A · C",
    hydroYears: 5,
    sixYear: false,
    shell: "Stored pressure",
  },
  foam: {
    key: "foam",
    label: "Foam (AFFF)",
    plate: "AB",
    classes: "A · B",
    hydroYears: 5,
    sixYear: false,
    shell: "Stored pressure",
  },
  k: {
    key: "k",
    label: "Wet chemical (Class K)",
    plate: "K",
    classes: "K",
    hydroYears: 5,
    sixYear: false,
    shell: "Stored pressure",
  },
  clean: {
    key: "clean",
    label: "Clean agent",
    plate: "CA",
    classes: "B · C",
    hydroYears: 12,
    sixYear: true,
    shell: "Halogenated, stored pressure",
  },
  classd: {
    key: "classd",
    label: "Class D powder",
    plate: "D",
    classes: "D",
    hydroYears: 12,
    sixYear: true,
    shell: "Stored pressure, mild steel",
  },
};

export const AGENT_LIST: Agent[] = Object.values(AGENTS);

export function agentOf(key: string): Agent {
  if (key in AGENTS) return AGENTS[key as AgentKey];
  return AGENTS.abc;
}
