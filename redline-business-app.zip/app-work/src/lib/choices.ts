export const MANUFACTURERS = [
  "Amerex",
  "Ansul",
  "Badger",
  "Buckeye",
  "Kidde",
  "Pyro-Chem",
  "Range Guard",
  "Strike First",
] as const;

export const EXT_MODELS = [
  "240",
  "Advantage 10",
  "B402",
  "B402S",
  "B456",
  "B5V",
  "B10V",
  "C260",
  "Cleanguard",
  "Cleanguard FE13",
  "K-Guard",
  "Pro 5",
  "Pro 10",
  "Red Line K",
] as const;

export const HOOD_MODELS = ["K-Guard", "PIRANHA", "R-102", "Whizzard"] as const;

export const RATINGS = [
  "2-A",
  "2-A:C",
  "2-A:K",
  "2-A:10-B:C",
  "3-A:40-B:C",
  "4-A:60-B:C",
  "4-A:80-B:C",
  "5-B:C",
  "10-B:C",
  "40-B:C",
  "60-B:C",
] as const;

export const SIZES = ["2.5 lb", "5 lb", "10 lb", "13 lb", "20 lb", "2.5 gal", "6 L"] as const;

export const AREAS = [
  "Aisle 3",
  "Cafeteria",
  "Electrical room",
  "Flammable cage",
  "Gym",
  "Imaging closet",
  "Kitchen",
  "Loading dock",
  "Office mezzanine",
  "Patio storage",
  "Science lab",
  "Server closet",
  "Staff kitchen",
  "West hallway",
] as const;

export const MOUNTS = [
  "Cabinet",
  "Column",
  "Floor stand",
  "Inside the door",
  "Vehicle bracket",
  "Wall bracket",
  "Wall hook",
] as const;

export const FINDINGS = [
  "Passed visual",
  "Gauge in the green",
  "Gauge in the red",
  "Hose cracked",
  "Pin or seal missing",
  "Tag missing",
  "Bracket loose",
  "Cylinder dented",
  "Obstructed",
  "Shell failed visual",
] as const;

export const CONTACTS = [
  "Dock office",
  "Facilities",
  "Front office",
  "Kitchen lead",
  "Manager on duty",
  "School office",
] as const;

export const CLIENT_NOTES = [
  "After hours lockbox",
  "Avoid the lunch rush",
  "Check in at the office",
  "Dock faces the yard",
  "Kitchen hood and dining room",
] as const;

export const JOB_NOTES = [
  "Annual inspection",
  "Follow up on deficiency",
  "Hydro and 6-year",
  "Recharge only",
  "Semi-annual hood",
] as const;

export const HOOD_NAMES = ["Cafeteria", "Cook line", "Fry line", "Grill", "Staff kitchen"] as const;

export const FUELS = ["Electric", "Gas", "Mixed", "Solid fuel"] as const;

export const HOOD_LOCATIONS = ["Cook line", "Fry station", "Main hood", "Prep hood", "Staff kitchen"] as const;

export const COUNTS = ["1", "2", "3", "4", "5", "6", "8", "10", "12"] as const;

export const PARTS = [
  "5 lb ABC recharge",
  "6-year internal",
  "10 lb ABC recharge",
  "20 lb ABC recharge",
  "Class K recharge",
  "CO2 recharge",
  "Fusible link",
  "Gauge",
  "Hood cylinder recharge",
  "Hose assembly",
  "Hydrostatic test",
  "New 5 lb ABC",
  "New 10 lb ABC",
  "Nozzle",
  "Semi-annual system service",
  "Service collar",
  "Vehicle bracket",
  "Wall hook",
] as const;

export const LABOR = [
  "Annual inspection",
  "Hood service",
  "Monthly inspection",
  "On-site labor",
  "Shop labor",
  "Travel",
] as const;

export const QTYS = ["1", "2", "3", "4", "5", "6", "8", "10", "12"] as const;

export const RATES = ["0", "15", "25", "35", "45", "65", "85", "125", "175", "250", "350"] as const;

export const PHOTO_CAPTIONS = [
  "6-year tag",
  "Cylinder damage",
  "Fusible links",
  "Gauge",
  "Hood cylinder",
  "Hydro stamp",
] as const;

export const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
] as const;

export const FALLBACK_CREWS = ["Shop", "Truck 1", "Truck 2", "Truck 3"] as const;
