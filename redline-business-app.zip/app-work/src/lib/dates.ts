const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const WEEKDAYS_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function parts(iso: string): [number, number, number] {
  const [y, m, d] = iso.split("-").map(Number);
  return [y, m, d];
}

function fromUTC(y: number, m: number, d: number): string {
  const dt = new Date(Date.UTC(y, m - 1, d));
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${dt.getUTCFullYear()}-${mm}-${dd}`;
}

/** Local calendar day as YYYY-MM-DD. Call from the browser, not during SSR. */
export function todayISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(iso: string, days: number): string {
  const [y, m, d] = parts(iso);
  return fromUTC(y, m, d + days);
}

export function addMonths(iso: string, months: number): string {
  const [y, m, d] = parts(iso);
  const base = new Date(Date.UTC(y, m - 1 + months, 1));
  const last = new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth() + 1, 0)).getUTCDate();
  const day = Math.min(d, last);
  return fromUTC(base.getUTCFullYear(), base.getUTCMonth() + 1, day);
}

export function addYears(iso: string, years: number): string {
  return addMonths(iso, years * 12);
}

export function diffDays(later: string, earlier: string): number {
  const [ay, am, ad] = parts(later);
  const [by, bm, bd] = parts(earlier);
  const ms = Date.UTC(ay, am - 1, ad) - Date.UTC(by, bm - 1, bd);
  return Math.round(ms / 86_400_000);
}

export function formatPretty(iso: string): string {
  const [, m, d] = parts(iso);
  const [y] = parts(iso);
  return `${MONTHS[m - 1]} ${d}, ${y}`;
}

export function formatShort(iso: string): string {
  const [, m, d] = parts(iso);
  return `${MONTHS[m - 1]} ${d}`;
}

export function weekdayShort(iso: string): string {
  const [y, m, d] = parts(iso);
  return WEEKDAYS_SHORT[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}

export function longDay(iso: string): string {
  const [y, m, d] = parts(iso);
  const wd = WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
  return `${wd}, ${MONTHS[m - 1]} ${d}`;
}
