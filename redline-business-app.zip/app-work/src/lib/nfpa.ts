import { agentOf } from "@/lib/agents";
import { addDays, addMonths, addYears, diffDays } from "@/lib/dates";
import type { Condition, Unit } from "@/lib/types";

export type ClockKey = "monthly" | "annual" | "six_year" | "hydro" | "semi" | "links" | "cleaning";
export type ClockState = "overdue" | "due" | "ok" | "unknown" | "na";
export type Worst = "overdue" | "due" | "unknown" | "ok" | "out";

export type Clock = {
  key: ClockKey;
  label: string;
  cite: string;
  last: string | null;
  next: string | null;
  state: ClockState;
  note: string;
};

export type Compliance = {
  clocks: Clock[];
  worst: Worst;
  headline: string;
};

const SOON: Record<ClockKey, number> = {
  monthly: 7,
  annual: 30,
  six_year: 60,
  hydro: 90,
  semi: 30,
  links: 30,
  cleaning: 14,
};

const WEIGHT: Record<ClockState, number> = {
  overdue: 4,
  unknown: 3,
  due: 2,
  ok: 1,
  na: 0,
};

const ORDER: ClockKey[] = ["hydro", "six_year", "annual", "monthly"];

function stateFor(next: string | null, today: string, soonDays: number): ClockState {
  if (!next) return "unknown";
  if (next < today) return "overdue";
  if (next <= addDays(today, soonDays)) return "due";
  return "ok";
}

export function compliance(
  unit: Pick<
    Unit,
    | "condition"
    | "agent"
    | "manufacturedOn"
    | "lastMonthly"
    | "lastAnnual"
    | "lastSixYear"
    | "lastHydro"
  >,
  today: string,
): Compliance {
  const agent = agentOf(unit.agent);
  const hydroAnchor = unit.lastHydro ?? unit.manufacturedOn;
  const nextHydro = hydroAnchor ? addYears(hydroAnchor, agent.hydroYears) : null;
  const sixAnchor = unit.lastSixYear ?? unit.lastHydro ?? unit.manufacturedOn;
  const nextSix = agent.sixYear && sixAnchor ? addYears(sixAnchor, 6) : null;
  const folded = Boolean(nextSix && nextHydro && nextSix >= nextHydro);

  const clocks: Clock[] = [
    {
      key: "monthly",
      label: "Monthly inspection",
      cite: "NFPA 10 §7.2",
      last: unit.lastMonthly,
      next: unit.lastMonthly ? addMonths(unit.lastMonthly, 1) : null,
      state: "ok",
      note: "",
    },
    {
      key: "annual",
      label: "Annual maintenance",
      cite: "NFPA 10 §7.3",
      last: unit.lastAnnual,
      next: unit.lastAnnual ? addYears(unit.lastAnnual, 1) : null,
      state: "ok",
      note: "",
    },
    {
      key: "six_year",
      label: "6-year internal",
      cite: "NFPA 10 §7.3.3",
      last: unit.lastSixYear ?? (agent.sixYear ? unit.lastHydro : null),
      next: folded ? nextHydro : nextSix,
      state: "na",
      note: !agent.sixYear
        ? "Not a separate trip on a 5-year hydrostatic cycle."
        : folded
          ? "Due with the hydrostatic test, not as its own visit."
          : "",
    },
    {
      key: "hydro",
      label: "Hydrostatic test",
      cite: `NFPA 10 Table 8.3.1 · every ${agent.hydroYears} years`,
      last: unit.lastHydro,
      next: nextHydro,
      state: "ok",
      note: !hydroAnchor
        ? "No hydrostatic date and no manufacture date on file."
        : unit.lastHydro
          ? ""
          : "Clock started from the manufacture date. Confirm the stamp on the cylinder.",
    },
  ];

  for (const clock of clocks) {
    if (clock.key === "six_year" && (!agent.sixYear || folded)) {
      clock.state = "na";
      continue;
    }
    clock.state = stateFor(clock.next, today, SOON[clock.key]);
  }

  if (unit.condition !== "in_service") {
    return {
      clocks,
      worst: "out",
      headline: unit.condition === "condemned" ? "Condemned" : "Out of service",
    };
  }

  let best: Clock | null = null;
  for (const key of ORDER) {
    const clock = clocks.find((item) => item.key === key);
    if (!clock) continue;
    if (!best || WEIGHT[clock.state] > WEIGHT[best.state]) best = clock;
  }

  let headline = "In service";
  if (best?.state === "overdue") headline = `${best.label} overdue`;
  else if (best?.state === "unknown") headline = `${best.label} not on file`;
  else if (best?.state === "due") headline = `${best.label} due soon`;

  const worst: Worst = clocks.some((clock) => clock.state === "overdue")
    ? "overdue"
    : clocks.some((clock) => clock.state === "unknown")
      ? "unknown"
      : clocks.some((clock) => clock.state === "due")
        ? "due"
        : "ok";

  return { clocks, worst, headline };
}

export function clockPhrase(clock: Clock, today: string): string {
  if (clock.state === "na") return clock.note || "Not required";
  if (clock.state === "unknown" || !clock.next) return "Not on file";
  if (clock.next < today) {
    const n = diffDays(today, clock.next);
    return n === 1 ? "1 day overdue" : `${n} days overdue`;
  }
  if (clock.next === today) return "Due today";
  const n = diffDays(clock.next, today);
  return n === 1 ? "Due tomorrow" : `Due in ${n} days`;
}

export function worstRank(worst: Worst): number {
  if (worst === "overdue") return 0;
  if (worst === "unknown") return 1;
  if (worst === "due") return 2;
  if (worst === "ok") return 3;
  return 4;
}

export function conditionLabel(condition: Condition): string {
  if (condition === "condemned") return "Condemned";
  if (condition === "out") return "Out of service";
  return "In service";
}
