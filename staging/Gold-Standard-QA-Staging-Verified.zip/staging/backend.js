/* =====================================================================
   Gold Standard — cloud backend (Supabase)
   Handles sign-in, company accounts, team roles, and gives the app a
   live, offline-tolerant data connection. The app itself is index.html.
   ===================================================================== */
(function () {
  'use strict';
  const cfg = window.GS_CONFIG || {};
  const configured = /^https:\/\/.+/.test(cfg.supabaseUrl || '') && (cfg.supabaseAnonKey || '').length > 20;
  const MEM_KEY = 'gs-membership', CO_KEY = 'gs-company-id';
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { v === null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (e) {} };

  let resolveReady;
  const B = {
    ready: new Promise(r => { resolveReady = r; }),
    sb: null, user: null, membership: null, memberships: [], company: null,
    role: null, companyId: null, installPrompt: null, appUrl: location.origin + location.pathname.replace(/index\.html$/, ''),
  };
  window.GSBackend = B;
  if (new URLSearchParams(location.search).get('portal')) B.portalToken = new URLSearchParams(location.search).get('portal');

  /* ---------------- install as an app ---------------- */
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
  }
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); B.installPrompt = e; });
  B.isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  B.isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent);

  /* ---------------- sign-in screens ---------------- */
  let screen = 'signin', note = '', busy = false;
  function overlay() {
    let el = document.getElementById('auth');
    if (!el) { el = document.createElement('div'); el.id = 'auth'; el.className = 'auth-wrap'; document.body.appendChild(el); }
    return el;
  }
  function hideOverlay() { const el = document.getElementById('auth'); if (el) el.remove(); }
  const logo = () => (window.LOGO ? window.LOGO(56) : '');
  function field(label, name, type = 'text', attrs = '') { return `<label class="fld"><span>${label}</span><input class="in" name="${name}" type="${type}" ${attrs}></label>`; }
  function show(next, msg) {
    screen = next || screen; note = msg || '';
    const el = overlay();
    const head = `<div class="auth-brand">${logo()}<div><div class="brand-name"><span class="gold">GOLD</span> STANDARD <span class="hub">SERVICE HUB</span></div><div class="brand-sub" style="display:block">Fire protection · Extinguishers · Kitchen suppression</div></div></div>`;
    const msg2 = note ? `<div class="auth-note">${note}</div>` : '';
    let body = '';
    if (!configured) {
      body = `<h2>Almost there</h2><p class="small">This copy of Gold Standard Service Hub isn’t connected to a database yet. Add your Supabase URL and public key to <b>config.js</b>, then upload the app again.</p>`;
    } else if (screen === 'loading') {
      body = `<h2>Signing you in…</h2><p class="small muted">Loading your company.</p>`;
    } else if (screen === 'signin') {
      body = `<h2>Sign in</h2>${msg2}<form data-auth="signin" class="stack">${field('Email', 'email', 'email', 'autocomplete="email" required')}${field('Password', 'password', 'password', 'autocomplete="current-password" required minlength="6"')}<button class="btn primary big block" ${busy ? 'disabled' : ''}>Sign in</button></form>
        <div class="row between small"><a href="#" data-auth-go="reset">Forgot password?</a><a href="#" data-auth-go="signup">Create an account</a></div>`;
    } else if (screen === 'signup') {
      body = `<h2>Create your account</h2>${msg2}<form data-auth="signup" class="stack">
        <div class="chips" role="group"><label class="chip"><input type="radio" name="kind" value="owner" checked data-auth-kind> New company</label><label class="chip"><input type="radio" name="kind" value="invited" data-auth-kind> I was invited</label></div>
        <div data-owner-only>${field('Company name', 'company', 'text', 'autocomplete="organization"')}</div>
        ${field('Your name', 'name', 'text', 'autocomplete="name" required')}${field('Email', 'email', 'email', 'autocomplete="email" required')}${field('Password (8+ characters)', 'password', 'password', 'autocomplete="new-password" required minlength="8"')}
        <p class="tiny muted" data-invited-only hidden>Use the same email address your company invited.</p>
        <label class="small" style="display:flex;gap:10px;align-items:flex-start"><input type="checkbox" name="agree" required style="width:20px;height:20px;margin-top:2px"><span>I agree to the <a href="legal.html#terms" target="_blank" rel="noopener">Terms of Service</a>, <a href="legal.html#aup" target="_blank" rel="noopener">Acceptable Use Policy</a> and <a href="legal.html#privacy" target="_blank" rel="noopener">Privacy Policy</a>.</span></label>
        <button class="btn primary big block" ${busy ? 'disabled' : ''}>Create account</button></form>
        <div class="small"><a href="#" data-auth-go="signin">I already have an account</a></div>`;
    } else if (screen === 'check') {
      body = `<h2>Check your email</h2>${msg2}<p class="small">Tap the confirmation link we sent, then come back and sign in.</p><button class="btn block" data-auth-go="signin">Back to sign in</button>`;
    } else if (screen === 'reset') {
      body = `<h2>Reset your password</h2>${msg2}<form data-auth="reset" class="stack">${field('Email', 'email', 'email', 'autocomplete="email" required')}<button class="btn primary big block" ${busy ? 'disabled' : ''}>Send reset link</button></form><div class="small"><a href="#" data-auth-go="signin">Back to sign in</a></div>`;
    } else if (screen === 'newpass') {
      body = `<h2>Choose a new password</h2>${msg2}<form data-auth="newpass" class="stack">${field('New password (8+ characters)', 'password', 'password', 'autocomplete="new-password" required minlength="8"')}<button class="btn primary big block">Save password</button></form>`;
    } else if (screen === 'nocompany') {
      body = `<h2>No company yet</h2>${msg2}<p class="small">You’re signed in as <b>${esc(B.user?.email)}</b>, but no company has invited this email. Ask your office to invite it under Company → Team &amp; logins, then sign in again — or start your own company.</p>
        <form data-auth="create" class="stack">${field('Company name', 'company', 'text', 'required')}<button class="btn primary block">Start a company</button></form>
        <div class="row between small"><a href="#" data-auth-go="retry">I’ve been invited — check again</a><a href="#" data-auth-go="signout">Sign out</a></div>`;
    }
    el.innerHTML = `<div class="auth-card">${head}${body}</div>`;
    const first = el.querySelector('input:not([type=radio])'); if (first && window.innerWidth > 700) first.focus();
  }

  async function authAction(kind, f) {
    const v = n => (f.elements[n]?.value || '').trim();
    busy = true;
    try {
      if (kind === 'signin') {
        const { error } = await B.sb.auth.signInWithPassword({ email: v('email'), password: f.elements.password.value });
        if (error) throw error;
        await afterSignIn();
      } else if (kind === 'signup') {
        const owner = f.elements.kind.value === 'owner';
        if (owner && !v('company')) throw new Error('Enter your company name.');
        const { data, error } = await B.sb.auth.signUp({ email: v('email'), password: f.elements.password.value,
          options: { emailRedirectTo: B.appUrl, data: { full_name: v('name'), company_name: owner ? v('company') : '', terms_version: window.LEGAL_VERSION || '1.0', terms_accepted_at: new Date().toISOString() } } });
        if (error) throw error;
        if (data.session) await afterSignIn(); else show('check', `We sent a link to <b>${esc(v('email'))}</b>.`);
      } else if (kind === 'reset') {
        const { error } = await B.sb.auth.resetPasswordForEmail(v('email'), { redirectTo: B.appUrl });
        if (error) throw error;
        show('check', `If <b>${esc(v('email'))}</b> has an account, a reset link is on its way.`);
      } else if (kind === 'newpass') {
        const { error } = await B.sb.auth.updateUser({ password: f.elements.password.value });
        if (error) throw error;
        await afterSignIn();
      } else if (kind === 'create') {
        const { error } = await B.sb.rpc('create_company', { p_name: v('company') });
        if (error) throw error;
        await afterSignIn();
      }
    } catch (e) {
      const m = String(e?.message || e);
      show(null, /invalid login/i.test(m) ? 'That email and password don’t match. Try again or reset your password.'
        : /email not confirmed/i.test(m) ? 'Confirm your email first — check your inbox for the link.'
        : /already registered/i.test(m) ? 'That email already has an account. Sign in instead.'
        : /failed to fetch|network/i.test(m) ? 'No connection. Check your signal and try again.' : esc(m));
    } finally { busy = false; }
  }
  document.addEventListener('submit', e => {
    const f = e.target.closest('form[data-auth]'); if (!f) return;
    e.preventDefault(); e.stopPropagation(); authAction(f.dataset.auth, f);
  }, true);
  document.addEventListener('click', e => {
    const a = e.target.closest('[data-auth-go]'); if (!a) return;
    e.preventDefault(); e.stopPropagation();
    const go = a.dataset.authGo;
    if (go === 'signout') B.signOut(); else if (go === 'retry') afterSignIn(); else show(go);
  }, true);
  document.addEventListener('change', e => {
    if (!e.target.matches('[data-auth-kind]')) return;
    const owner = e.target.value === 'owner', card = e.target.closest('form');
    card.querySelector('[data-owner-only]').hidden = !owner;
    card.querySelector('[data-invited-only]').hidden = owner;
  }, true);

  /* ---------------- company + role ---------------- */
  async function afterSignIn() {
    show('loading');
    const { data: sess } = await B.sb.auth.getSession();
    B.user = sess?.session?.user || null;
    if (!B.user) { show('signin'); return; }
    let mems = null;
    try {
      const { data, error } = await B.sb.rpc('bootstrap');
      if (error) throw error;
      mems = data || [];
    } catch (e) {
      // Offline start: use the last company this device signed into.
      try { const cached = JSON.parse(lsGet(MEM_KEY) || 'null'); if (cached && cached.user_id === B.user.id) mems = [cached]; } catch (x) {}
      if (!mems) { show('signin', 'No connection, and this device hasn’t signed in before. Connect and try again.'); return; }
    }
    if (!mems.length) { show('nocompany'); return; }
    B.memberships = mems;
    const want = lsGet(CO_KEY);
    B.membership = mems.find(m => m.company_id === want) || mems[0];
    B.companyId = B.membership.company_id; B.role = B.membership.role;
    lsSet(CO_KEY, B.companyId); lsSet(MEM_KEY, JSON.stringify(B.membership));
    try { const { data } = await B.sb.from('companies').select('*').eq('id', B.companyId).maybeSingle(); if (data) { B.company = data; lsSet('gs-company-row-' + B.companyId, JSON.stringify(data)); } } catch (e) {}
    if (!B.company) { try { const cachedCompany = JSON.parse(lsGet('gs-company-row-' + B.companyId) || 'null'); if (cachedCompany && cachedCompany.id === B.companyId) B.company = cachedCompany; } catch (e) {} }
    hideOverlay();
    if (/[?&]billing=success/.test(location.search)) { [3000, 8000, 20000].forEach(ms => setTimeout(B.refreshCompany, ms)); history.replaceState(null, '', location.pathname + location.hash); }
    resolveReady(makeDb(B.companyId));
  }
  B.signOut = async () => {
    const pending = typeof window.outCount === 'function' ? window.outCount() : 0;
    if (pending && !window.confirm(pending + ' change' + (pending > 1 ? 's have' : ' has') + ' not reached the server yet. Signing out now will lose ' + (pending > 1 ? 'them' : 'it') + '. Sign out anyway?')) return;
    try { await B.sb.auth.signOut(); } catch (e) {}
    // Remove this device's offline copy of the company's records.
    try { if (B.companyId) indexedDB.deleteDatabase('gs-' + B.companyId); } catch (e) {}
    ['gs-outbox', 'gs-outbox-' + B.companyId, 'gs-brand', CO_KEY].forEach(k => { try { localStorage.removeItem(k); } catch (e) {} });
    lsSet(MEM_KEY, null); location.reload();
  };
  B.acceptTerms = async version => {
    const { data, error } = await B.sb.auth.updateUser({ data: { terms_version: version, terms_accepted_at: new Date().toISOString() } });
    if (error) throw error; if (data?.user) B.user = data.user;
  };
  B.switchCompany = cid => {
    if (!B.memberships?.some(m => m.company_id === cid)) return;
    if (cid === B.companyId) return;
    const pending = typeof window.outCount === 'function' ? window.outCount() : 0;
    if (pending && !window.confirm(pending + ' unsynced change' + (pending === 1 ? '' : 's') + ' remain on this device. Switch companies now? The changes will remain on this device until you return and sync.')) return;
    lsSet(CO_KEY, cid); location.reload();
  };

  /* ---------------- team management (admins) ---------------- */
  B.team = async () => {
    const [m, i] = await Promise.all([
      B.sb.from('memberships').select('*').eq('company_id', B.companyId).order('created_at'),
      B.sb.from('invitations').select('*').eq('company_id', B.companyId).order('created_at'),
    ]);
    if (m.error) throw m.error; if (i.error) throw i.error;
    return { members: m.data || [], invites: i.data || [] };
  };
  B.invite = async (email, role, techId) => {
    const { error } = await B.sb.from('invitations').upsert({ company_id: B.companyId, email: email.trim().toLowerCase(), role, tech_id: techId || null, invited_by: B.user.id }, { onConflict: 'company_id,email' });
    if (error) throw error;
  };
  B.cancelInvite = async id => { const { error } = await B.sb.from('invitations').delete().eq('id', id); if (error) throw error; };
  B.updateMember = async (userId, patch) => { const { error } = await B.sb.from('memberships').update(patch).eq('company_id', B.companyId).eq('user_id', userId); if (error) throw error; };
  B.removeMember = async userId => { const { error } = await B.sb.from('memberships').delete().eq('company_id', B.companyId).eq('user_id', userId); if (error) throw error; };

  /* ---------------- data connection ----------------
     Same interface the app already uses (collection/doc, onSnapshot,
     set/update/delete), backed by the "docs" table with live updates. */
  function makeDb(cid) {
    const sb = B.sb, cache = {}, colListeners = {}, docListeners = {}, loaded = new Set();
    const toErr = e => {
      const m = String(e?.message || e || ''), c = e?.code;
      if (c === 'P0002' || /not found/i.test(m) || c === '42501' || /row-level security|permission denied/i.test(m)) return { code: 'invalid_argument', message: m };
      if (/jwt|refresh token|not authenticated/i.test(m)) return { code: 'revoked', message: m };
      if (/quota|exceed|too large/i.test(m)) return { code: 'quota_exceeded', message: m };
      return { code: 'unavailable', message: m };
    };
    const snapDocs = col => [...(cache[col] || new Map()).entries()].map(([id, d]) => ({ id, exists: true, data: () => d }));
    const meta = { fromCache: false, hasPendingWrites: false };
    const emitCol = col => (colListeners[col] || new Set()).forEach(fn => { try { fn({ docs: snapDocs(col), metadata: meta }); } catch (e) { console.error(e); } });
    const emitDoc = (col, id) => (docListeners[col + '/' + id] || new Set()).forEach(fn => { const d = cache[col]?.get(id); try { fn({ id, exists: !!d, data: () => d, metadata: meta }); } catch (e) { console.error(e); } });
    const deepMerge = (a, b) => { if (!a || typeof a !== 'object' || Array.isArray(a) || !b || typeof b !== 'object' || Array.isArray(b)) return b; const o = { ...a }; for (const k in b) o[k] = deepMerge(a[k], b[k]); return o; };

    // Live changes that arrive while a collection is being (re)loaded are held and replayed on top,
    // so a slow reload can't roll a record back to an older copy.
    const inflight = {}, heldEvents = {};
    async function fetchCol(col) {
      if (inflight[col]) return inflight[col];
      heldEvents[col] = [];
      inflight[col] = (async () => {
        const rows = []; let from = 0;
        for (;;) {
          // A fixed sort order is required: without it, paging past 1,000 records can skip or repeat rows.
          const { data, error } = await sb.from('docs').select('id,data').eq('company_id', cid).eq('col', col).order('id', { ascending: true }).range(from, from + 999);
          if (error) throw error;
          rows.push(...data); if (data.length < 1000) break; from += 1000;
        }
        const map = new Map(rows.map(r => [r.id, r.data]));
        for (const ev of heldEvents[col] || []) { if (ev.del) map.delete(ev.id); else map.set(ev.id, ev.data); }
        cache[col] = map; loaded.add(col);
      })();
      try { await inflight[col]; } finally { delete inflight[col]; delete heldEvents[col]; }
    }
    async function load(col, retry = 0) {
      try { await fetchCol(col); emitCol(col); Object.keys(docListeners).filter(k => k.startsWith(col + '/')).forEach(k => emitDoc(col, k.slice(col.length + 1))); }
      catch (e) { if (retry < 20) setTimeout(() => load(col, retry + 1), Math.min(30000, 3000 * (retry + 1))); }
    }
    let lastRefresh = 0;
    const refreshAll = (force) => {
      // Phones fire "visible" constantly; a full reload every time wastes data and battery.
      if (!force && Date.now() - lastRefresh < 30000) return; lastRefresh = Date.now();
      [...new Set([...Object.keys(colListeners), ...Object.keys(docListeners).map(k => k.split('/')[0])])].forEach(c => load(c));
    };
    sb.channel('docs-' + cid)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'docs', filter: 'company_id=eq.' + cid }, p => {
        const row = (p.new && p.new.col) ? p.new : p.old; if (row && row.company_id && row.company_id !== cid) return; // delete events can't be filtered server-side
        if (!row || !row.col) { if (p.eventType === 'DELETE') refreshAll(); return; }
        if (heldEvents[row.col]) heldEvents[row.col].push({ id: row.id, del: p.eventType === 'DELETE', data: p.new?.data });
        if (!cache[row.col]) return;
        if (p.eventType === 'DELETE') cache[row.col].delete(row.id); else cache[row.col].set(row.id, p.new.data);
        emitCol(row.col); emitDoc(row.col, row.id);
      })
      .subscribe(status => { if (status === 'SUBSCRIBED') refreshAll(true); });
    window.addEventListener('online', () => refreshAll(true));
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refreshAll(); });

    const dataUrlToBlob = u => { const [h, b] = u.split(','); const bin = atob(b); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: (h.match(/data:(.*?);/) || [])[1] || 'image/jpeg' }); };
    function ref(col, id) {
      const key = col + '/' + id;
      return {
        id, path: key,
        async set(body) {
          let data = body;
          if (col === 'photos' && typeof body.data === 'string' && body.data.startsWith('data:')) {
            const path = `${cid}/${id}.jpg`;
            const up = await sb.storage.from('photos').upload(path, dataUrlToBlob(body.data), { upsert: true, contentType: 'image/jpeg' });
            if (up.error && !/exists/i.test(up.error.message || '')) throw toErr(up.error);
            data = { ...body, data: undefined, path };
            delete data.data;
          }
          const { error } = await sb.from('docs').upsert({ company_id: cid, col, id, data, updated_at: new Date().toISOString(), updated_by: B.user.id }, { onConflict: 'company_id,col,id' });
          if (error) throw toErr(error);
          if (cache[col]) { cache[col].set(id, data); emitCol(col); emitDoc(col, id); }
        },
        async update(patch) {
          const { error } = await sb.rpc('merge_doc', { p_company: cid, p_col: col, p_id: id, p_patch: patch });
          if (error) throw toErr(error);
          if (cache[col]?.has(id)) { cache[col].set(id, deepMerge(cache[col].get(id), patch)); emitCol(col); emitDoc(col, id); }
        },
        async delete() {
          const { error } = await sb.from('docs').delete().eq('company_id', cid).eq('col', col).eq('id', id);
          if (error) throw toErr(error);
          if (cache[col]) { cache[col].delete(id); emitCol(col); emitDoc(col, id); }
        },
        async get() { if (!loaded.has(col)) await fetchCol(col); const d = cache[col].get(id); return { id, exists: !!d, data: () => d }; },
        onSnapshot(next, onErr) {
          (docListeners[key] ||= new Set()).add(next);
          if (loaded.has(col)) emitDoc(col, id); else load(col);
          return () => docListeners[key].delete(next);
        },
      };
    }
    function collection(col, filter) {
      return {
        doc: id => ref(col, id),
        where: (field, op, value) => collection(col, { field, value }),
        async get() {
          let q = sb.from('docs').select('id,data').eq('company_id', cid).eq('col', col);
          if (filter) q = q.eq('data->>' + filter.field, String(filter.value));
          const { data, error } = await q;
          if (error) throw toErr(error);
          let rows = data || [];
          if (col === 'photos' && rows.length) {
            const paths = rows.map(r => r.data.path).filter(Boolean);
            const { data: signed } = paths.length ? await sb.storage.from('photos').createSignedUrls(paths, 60 * 60 * 24 * 7) : { data: [] };
            const byPath = Object.fromEntries((signed || []).map(s => [s.path, s.signedUrl]));
            rows = rows.map(r => ({ ...r, data: { ...r.data, data: byPath[r.data.path] || r.data.data || '' } }));
          }
          return { docs: rows.map(r => ({ id: r.id, exists: true, data: () => r.data })) };
        },
        onSnapshot(next, onErr) {
          (colListeners[col] ||= new Set()).add(next);
          if (loaded.has(col)) emitCol(col); else load(col);
          return () => colListeners[col].delete(next);
        },
      };
    }
    return { collection: c => collection(c), doc: path => { const [c, id] = path.split('/'); return ref(c, id); } };
  }

  /* ---------------- server functions: billing and email ---------------- */
  const invoke = async (name, body) => {
    const { data, error } = await B.sb.functions.invoke(name, { body: { ...body, companyId: B.companyId } });
    if (error) { let m = error.message; try { const j = await error.context?.json?.(); if (j?.error) m = j.error; } catch (e) {} throw new Error(m); }
    if (data?.error) throw new Error(data.error);
    return data;
  };
  if (cfg.billingEnabled || cfg.billingTestCompanyId) B.billing = {
    checkout: async (plan, interval) => { if (!cfg.billingEnabled && (B.companyId !== cfg.billingTestCompanyId || B.company?.plan === 'comp')) throw new Error('Checkout is restricted to the sandbox test organization'); return (await invoke('stripe-checkout', { plan, interval, returnUrl: B.appUrl })).url; },
    manage: async () => { if (!cfg.billingEnabled && (B.companyId !== cfg.billingTestCompanyId || B.company?.plan === 'comp')) throw new Error('Billing portal is restricted to the sandbox test organization'); return (await invoke('stripe-portal', { returnUrl: B.appUrl })).url; },
  };
  B.sendEmail = payload => invoke('send-email', payload);
  B.refreshCompany = async () => {
    try { const { data } = await B.sb.from('companies').select('*').eq('id', B.companyId).maybeSingle(); if (data) { B.company = data; lsSet('gs-company-row-' + B.companyId, JSON.stringify(data)); window.renderSoon?.(); } } catch (e) {}
  };

  /* ---------------- customer portal (no login) ---------------- */
  const portalToken = new URLSearchParams(location.search).get('portal');
  function startPortalBackend() {
    B.portalToken = portalToken;
    const client = () => B.sb || (B.sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: false, autoRefreshToken: false } }));
    const rpc = async (fn, args) => { if (!configured || !window.supabase) throw new Error('not configured'); const { data, error } = await client().rpc(fn, { p_token: portalToken, ...args }); if (error) throw new Error(error.message); return data; };
    B.portalGet = () => rpc('portal_get', {});
    B.portalQuote = (id, action, name) => rpc('portal_quote', { p_quote: id, p_action: action, p_name: name });
    B.portalRequest = (title, body, contact) => rpc('portal_request', { p_title: title, p_body: body, p_contact: contact });
  }
  if (portalToken) startPortalBackend();

  /* ---------------- start ---------------- */
  function start() {
    if (!configured || !window.supabase) { show(); return; }
    if (portalToken) return;   // customer portal: no sign-in screen
    B.sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
    B.sb.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') show('newpass');
      if (event === 'SIGNED_OUT') location.reload();
    });
    B.sb.auth.getSession().then(({ data }) => {
      if (/type=recovery/.test(location.hash)) { show('newpass'); return; }
      if (data?.session) afterSignIn(); else show('signin');
    }).catch(() => show('signin'));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
