Gold Standard QA build. Uses separate QA Supabase project. NEVER deploy to production URL. No production data, login, or billing. Billing and email disabled.
