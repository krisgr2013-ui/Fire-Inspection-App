/* Gold Standard offline support: keeps the app itself on the device so it opens
   with no signal. Your records sync separately through the app's own outbox. */
const VERSION = 'gs-1.13.3-offline-navigation';
const SHELL = ['./', './index.html', './backend.js', './config.js', './manifest.webmanifest', './legal.html',
  './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png', './icons/favicon-32.png',
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js',
  'https://cdn.jsdelivr.net/npm/@zxing/library@0.20.0/umd/index.min.js'];
// Weak signal (a basement, a walk-in cooler) can leave a request hanging; give up after 4 seconds and use the saved copy.
const fetchSoon = (req, ms = 4000) => new Promise((resolve, reject) => {
  const t = setTimeout(() => reject(new Error('slow network')), ms);
  fetch(req).then(r => { clearTimeout(t); resolve(r); }, err => { clearTimeout(t); reject(err); });
});
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => null)))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (/supabase\.(co|in)$/.test(url.hostname) || url.pathname.includes('/auth/v1') || url.pathname.includes('/rest/v1')) return; // live data: network only
  if (req.mode === 'navigate') {
    // Only a good copy of the app page itself becomes the offline copy; other pages (legal.html) and error pages are kept separately or not at all.
    const isApp = /\/(index\.html)?$/.test(url.pathname);
    e.respondWith(fetchSoon(req).then(res => {
      if (res && res.ok && res.type === 'basic') { const copy = res.clone(); caches.open(VERSION).then(c => c.put(isApp ? './index.html' : url.pathname, copy)); }
      return res;
    }).catch(() => caches.match(isApp ? './index.html' : req).then(hit => hit || new Response('Offline response unavailable. Reconnect to open this page.', {status: 503, headers: {'Content-Type': 'text/plain; charset=utf-8'}}))));
    return;
  }
  const cacheable = url.origin === location.origin || /(^|\.)(jsdelivr\.net|googleapis\.com|gstatic\.com)$/.test(url.hostname);
  if (!cacheable) return;
  const save = res => { if (res && (res.ok || res.type === 'opaque')) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); } return res; };
  // The app's own scripts (backend.js, config.js) must always match the page that was just loaded: network first, cache when offline.
  if (url.origin === location.origin && /\.(js|json|webmanifest|css)$/.test(url.pathname)) {
    e.respondWith(fetchSoon(req).then(save).catch(() => caches.match(req).then(hit => hit || fetch(req))));
    return;
  }
  // Fonts, icons and pinned library versions never change: cache first.
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(save)));
});
