/* Gold Standard settings — fill these two values from Supabase:
   Project Settings → API → "Project URL" and the "anon public" key.
   The anon key is safe to publish; your data is protected by the database rules. */
window.GS_CONFIG = {
  supabaseUrl: 'https://zhhgbwxjyhypxzqqbcqu.supabase.co',
  supabaseAnonKey: 'sb_publishable_Erd3MiwXvwwYIVO-KjdOQA_lRKVfOe4',
  // Turn these on after the Stripe and email server functions are deployed (see the launch guide).
  billingEnabled: false,
  // Sandbox checkout is exposed ONLY to this isolated test organization.
  billingTestCompanyId: '',
  emailEnabled: false,
  // Your business details for the legal pages (Terms, Privacy Policy). Fill these in before launch.
  legal: {
    providerName: '',   // e.g. 'Gold Standard Software LLC'
    state: '',          // e.g. 'Washington'
    county: '',         // e.g. 'Yakima'
    address: '',        // mailing address for legal notices
    supportEmail: '',   // e.g. 'support@yourdomain.com'
    privacyEmail: '',   // e.g. 'privacy@yourdomain.com'
    effectiveDate: '',  // e.g. 'December 1, 2026'
  },
};
